"""Wrap site/index.html (artifact source, no doctype) into site/steerbench.html (standalone)."""

from pathlib import Path

SITE = Path(__file__).resolve().parent.parent / "site"


def main() -> None:
    s = (SITE / "index.html").read_text(encoding="utf-8")
    i = s.index("</style>") + len("</style>")
    head, body = s[:i], s[i:]
    head = head.replace('<meta name="claude:viewport-fit-sides" content="cover">\n', "")
    doc = (
        '<!doctype html>\n<html lang="en">\n<head>\n<meta charset="utf-8">\n'
        '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n'
        + head
        + "\n<style>body{margin:0}img{max-width:100%}[hidden]{display:none!important}"
        ":root{padding-top:env(safe-area-inset-top,0px);"
        "padding-bottom:env(safe-area-inset-bottom,0px)}</style>\n"
        "</head>\n<body>\n" + body.strip() + "\n</body>\n</html>\n"
    )
    (SITE / "steerbench.html").write_text(doc, encoding="utf-8")
    print(f"wrote {SITE / 'steerbench.html'}")


if __name__ == "__main__":
    main()
