#!/usr/bin/env bash
# Full SteerBench x Tinker experiment. Needs TINKER_API_KEY and your traces file.
#
#   TRACES=path/to/steerbench_traces.jsonl ./run_all.sh
#
# Every step writes predictions + metrics + meta.json, so any step can be re-run alone.
# Start with SMOKE=1 to push 20 traces through every arm before spending on the full run.
set -euo pipefail

: "${TRACES:?set TRACES=path/to/your/traces.jsonl}"
: "${TINKER_API_KEY:?export TINKER_API_KEY first}"
MODEL="${MODEL:-meta-llama/Llama-3.2-1B}"
TAG="${TAG:-llama1b}"
LIMIT=""
if [[ "${SMOKE:-0}" == "1" ]]; then LIMIT="limit=20"; TAG="${TAG}_smoke"; fi

python -m steerbench_tinker.prepare_data --traces "$TRACES" --out data

# 1. Zero-shot, two readouts of the same base model.
#    generative: the model must write the JSON (strict + lenient views)
#    decision:   logprob over the 5 primitives, no format to get wrong
python -m steerbench_tinker.eval_generative out="results/${TAG}/0_zeroshot_generative" model_name="$MODEL" $LIMIT
python -m steerbench_tinker.eval_decision   out="results/${TAG}/0_zeroshot_decision"   model_name="$MODEL" $LIMIT

if [[ "${SMOKE:-0}" == "1" ]]; then
  python -m steerbench_tinker.analyze summary "results/${TAG}"
  echo "smoke run done; rerun without SMOKE=1 for the full experiment"
  exit 0
fi

sampler() {  # last sampler checkpoint written by a cookbook training run
  python - "$1" <<'EOF'
import sys
from tinker_cookbook import checkpoint_utils
rec = checkpoint_utils.get_last_checkpoint(sys.argv[1], required_key="sampler_path")
print(rec.sampler_path if rec else "")
EOF
}

# 2. SFT on the training traces, then score it.
python -m steerbench_tinker.train_sft log_path="runs/${TAG}/sft" model_name="$MODEL"
python -m steerbench_tinker.eval_generative out="results/${TAG}/1_sft" model_name="$MODEL" \
  checkpoint="$(sampler "runs/${TAG}/sft")"

# 3. RL from the SFT checkpoint: asymmetric reward (main) and symmetric (ablation).
for PRESET in asymmetric symmetric; do
  python -m steerbench_tinker.train_rl log_path="runs/${TAG}/rl_${PRESET}" model_name="$MODEL" \
    sft_log_path="runs/${TAG}/sft" dataset_builder.reward_preset="$PRESET"
  python -m steerbench_tinker.eval_generative out="results/${TAG}/2_rl_${PRESET}" model_name="$MODEL" \
    checkpoint="$(sampler "runs/${TAG}/rl_${PRESET}")"
done

# 4. Decision readout trained with cross-entropy (writes its own final_eval).
python -m steerbench_tinker.train_decision log_path="runs/${TAG}/decision" model_name="$MODEL"
mkdir -p "results/${TAG}/3_decision_trained"
cp "runs/${TAG}/decision/final_eval/"* "results/${TAG}/3_decision_trained/"

# 5. Tables and paired comparisons.
python -m steerbench_tinker.analyze summary "results/${TAG}" --out "results/${TAG}/summary.json"
python -m steerbench_tinker.analyze compare "results/${TAG}/1_sft" "results/${TAG}/2_rl_asymmetric"
python -m steerbench_tinker.analyze compare "results/${TAG}/2_rl_symmetric" "results/${TAG}/2_rl_asymmetric"
python -m steerbench_tinker.analyze compare "results/${TAG}/1_sft" "results/${TAG}/3_decision_trained"
