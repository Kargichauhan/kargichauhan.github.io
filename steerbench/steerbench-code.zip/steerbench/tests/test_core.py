"""Unit tests for the pure-Python core (no Tinker, no network)."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from steerbench_tinker.metrics import Scored, compute, paired_difference
from steerbench_tinker.parse import ParseResult, ParseStatus, parse_lenient, parse_strict
from steerbench_tinker.prompt import sft_conversation, user_message
from steerbench_tinker.reward import PRESETS, outcome, score
from steerbench_tinker.schema import ACTIONS, TraceFormatError, load_traces
from steerbench_tinker.split import split_traces

FIX = Path(__file__).parent / "fixtures"


# ---------------------------------------------------------------- parsing
@pytest.mark.parametrize(
    "text,status,action",
    [
        ('{"action": "ASK", "rationale": "x"}', ParseStatus.OK, "ASK"),
        ('  {"action": "wait"}\n', ParseStatus.OK, "WAIT"),
        ('```json\n{"action": "FORGET"}\n```', ParseStatus.OK, "FORGET"),
        ('Sure! {"action": "ACT"}', ParseStatus.NO_JSON, None),
        ('{"action": "ACT"', ParseStatus.INVALID_JSON, None),
        ('{"decision": "ACT"}', ParseStatus.MISSING_ACTION, None),
        ('{"action": "PROCEED"}', ParseStatus.UNKNOWN_ACTION, None),
        ("", ParseStatus.EMPTY, None),
        ('["ACT"]', ParseStatus.NO_JSON, None),
    ],
)
def test_parse_strict(text, status, action):
    r = parse_strict(text)
    assert r.status is status
    assert r.action == action


@pytest.mark.parametrize(
    "text,action,status",
    [
        ('Sure! {"action": "ACT", "rationale": "ok"} Hope that helps.', "ACT", ParseStatus.OK),
        ("I would ASK the user first.", "ASK", ParseStatus.OK),
        ("Either ASK or WAIT could work.", None, ParseStatus.AMBIGUOUS),
        ("I'll go ahead and fix it.", None, ParseStatus.NO_JSON),
        ('{"foo": 1} then {"action": "REMEMBER"}', "REMEMBER", ParseStatus.OK),
        # "actually" contains ACT as a substring but not as a word: must not count
        ("Actually, let me think.", None, ParseStatus.NO_JSON),
    ],
)
def test_parse_lenient(text, action, status):
    r = parse_lenient(text)
    assert r.action == action
    assert r.status is status


def test_lenient_never_overrides_a_strict_parse():
    text = '{"action": "WAIT", "rationale": "do not ACT yet"}'
    assert parse_strict(text).action == parse_lenient(text).action == "WAIT"


# ---------------------------------------------------------------- reward
def test_outcome_classes():
    assert outcome("ASK", "ASK") == "correct"
    assert outcome("ASK", "ACT") == "premature_act"
    assert outcome("ACT", "WAIT") == "missed_act"
    assert outcome("WAIT", "ASK") == "other_wrong"
    assert outcome("WAIT", None) == "invalid"


@pytest.mark.parametrize("preset", sorted(PRESETS))
def test_garbage_is_never_a_good_bet(preset):
    """For every gold label, an invalid answer earns strictly less than every valid
    non-ACT answer, so emitting garbage is never a way to hedge."""
    cfg = PRESETS[preset]
    for gold in ACTIONS:
        invalid, _ = score(gold, ParseResult(ParseStatus.INVALID_JSON), cfg)
        for pred in ACTIONS:
            if pred == "ACT":
                continue
            valid, _ = score(gold, ParseResult(ParseStatus.OK, pred), cfg)
            assert invalid < valid, (preset, gold, pred)


def test_asymmetric_prices_premature_action_highest():
    cfg = PRESETS["asymmetric"]
    assert cfg.premature_act < cfg.invalid < cfg.missed_act < cfg.other_wrong < cfg.correct


# ---------------------------------------------------------------- metrics
def _s(i, gold, pred, domain="d", probs=None):
    return Scored(str(i), domain, gold, pred, "ok" if pred else "no_json", probs)


def test_metrics_hand_computed():
    items = [
        _s(1, "ACT", "ACT"),
        _s(2, "ACT", "ASK"),  # missed action
        _s(3, "ASK", "ACT"),  # premature
        _s(4, "WAIT", "WAIT"),
        _s(5, "REMEMBER", None),  # unparseable
    ]
    m = compute(items, n_boot=200)
    assert m["accuracy"] == pytest.approx(2 / 5)
    assert m["parse_rate"] == pytest.approx(4 / 5)
    assert m["accuracy_on_parsed"] == pytest.approx(2 / 4)
    assert m["premature_action_rate"] == pytest.approx(1 / 3)  # 1 of 3 non-ACT golds
    assert m["missed_action_rate"] == pytest.approx(1 / 2)
    assert m["confusion"]["REMEMBER"]["INVALID"] == 1
    assert m["per_action"]["ACT"]["precision"] == pytest.approx(1 / 2)
    lo, hi = m["accuracy_ci95"]
    assert 0.0 <= lo <= m["accuracy"] <= hi <= 1.0
    assert m["mean_reward"]["asymmetric"] == pytest.approx((1 - 0.25 - 1 + 1 - 0.5) / 5)


def test_bootstrap_is_deterministic():
    items = [_s(i, "ACT", "ACT" if i % 3 else "ASK") for i in range(60)]
    assert compute(items)["accuracy_ci95"] == compute(items)["accuracy_ci95"]


def test_calibration_perfect_and_uniform():
    gold = ["ACT", "ASK", "WAIT", "REMEMBER", "FORGET"]
    perfect = [_s(i, g, g, probs={a: float(a == g) for a in ACTIONS}) for i, g in enumerate(gold)]
    c = compute(perfect)["calibration"]
    assert c["brier"] == pytest.approx(0.0)
    assert c["ece"] == pytest.approx(0.0)
    uniform = [_s(i, g, "ACT", probs={a: 0.2 for a in ACTIONS}) for i, g in enumerate(gold)]
    assert compute(uniform)["calibration"]["brier"] == pytest.approx(0.8)


def test_paired_difference():
    a = [_s(i, "ASK", "ACT") for i in range(50)]
    b = [_s(i, "ASK", "ASK" if i < 30 else "ACT") for i in range(50)]
    d = paired_difference(a, b, n_boot=1000)
    assert d["difference"] == pytest.approx(0.6)
    assert d["b_fixes"] == 30 and d["b_breaks"] == 0
    assert d["significant_at_95"]


# ---------------------------------------------------------------- schema + split
def test_load_fixture_traces():
    traces = load_traces(FIX / "fixture_traces.jsonl")
    assert len(traces) == 12
    assert {t.gold_action for t in traces} == set(ACTIONS)
    fx5 = next(t for t in traces if t.id == "fx-005")
    assert fx5.memory == ("FX rate source: ECB daily", "vendor list v1 (superseded)")


def test_alt_layout_aliases_and_split_names():
    traces = load_traces(FIX / "fixture_alt_layout.json")
    assert [t.gold_action for t in traces] == ["WAIT", "ACT"]
    assert traces[0].domain == "science_qa" and traces[0].split == "test"
    assert traces[1].memory == ("a", "b")


def test_bad_label_reports_location(tmp_path):
    p = tmp_path / "bad.jsonl"
    p.write_text(
        json.dumps({"id": "1", "domain": "x", "task": "t", "observation": "o", "action": "GO"})
        + "\n"
    )
    with pytest.raises(TraceFormatError, match=r"bad.jsonl:1: .*'GO'"):
        load_traces(p)


def test_duplicate_ids_rejected(tmp_path):
    rec = {"id": "1", "domain": "x", "task": "t", "observation": "o", "action": "ACT"}
    p = tmp_path / "dup.jsonl"
    p.write_text(json.dumps(rec) + "\n" + json.dumps(rec) + "\n")
    with pytest.raises(TraceFormatError, match="duplicate"):
        load_traces(p)


def test_field_map(tmp_path):
    p = tmp_path / "m.jsonl"
    rec = {"id": "1", "domain": "x", "task": "t", "observation": "o", "meta": {"y": "forget"}}
    p.write_text(json.dumps(rec) + "\n")
    assert load_traces(p, {"gold_action": "meta.y"})[0].gold_action == "FORGET"


def test_split_is_deterministic_disjoint_and_stratified():
    traces = load_traces(FIX / "fixture_traces.jsonl") * 1
    tr1, te1, _ = split_traces(traces, 0.25, seed=0)
    _tr2, te2, _ = split_traces(list(reversed(traces)), 0.25, seed=0)
    assert [t.id for t in te1] == [t.id for t in te2]  # independent of file order
    assert not {t.id for t in tr1} & {t.id for t in te1}
    assert len(tr1) + len(te1) == len(traces)


def test_existing_split_is_honored():
    traces = load_traces(FIX / "fixture_alt_layout.json")
    _train, test, how = split_traces(traces)
    assert [t.id for t in test] == ["alt-1"] and how == "existing split field"


# ---------------------------------------------------------------- prompt
def test_prompt_never_leaks_the_label():
    for t in load_traces(FIX / "fixture_traces.jsonl"):
        assert t.rationale is None or t.rationale not in user_message(t)
        conv = sft_conversation(t)
        assert json.loads(conv["messages"][-1]["content"])["action"] == t.gold_action
        assert all(m["role"] != "assistant" for m in conv["messages"][:-1])
