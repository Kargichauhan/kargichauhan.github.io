Hand-written fixtures for unit tests only. They are not SteerBench benchmark data
and no result anywhere is computed on them.
