"""Integration tests against the real tinker / tinker-cookbook packages.

No API key or network is needed: a byte-level fake renderer stands in for a
tokenizer, and the environment is driven by a scripted policy through the same
``initial_observation`` / ``step`` interface the cookbook's rollout loop uses.
"""

from __future__ import annotations

import asyncio
from pathlib import Path

import pytest

pytest.importorskip("tinker_cookbook")

import tinker
from tinker_cookbook.renderers.base import ParseTermination

from steerbench_tinker.env import SteerBenchEnv, SteerBenchRLDataset
from steerbench_tinker.prompt import SYSTEM_PROMPT
from steerbench_tinker.reward import PRESETS
from steerbench_tinker.schema import load_traces

FIX = Path(__file__).parent / "fixtures"
TRUNC = 0  # a leading 0 byte marks a cut-off generation in the fake renderer


class FakeRenderer:
    """Bytes in, bytes out. Enough of the Renderer interface for ProblemEnv."""

    def get_stop_sequences(self):
        return ["\n\nUser:"]

    def build_generation_prompt(self, messages):
        text = "".join(f"{m['role']}: {m['content']}\n" for m in messages) + "assistant:"
        return tinker.ModelInput.from_ints(list(text.encode()))

    def parse_response(self, tokens):
        if tokens and tokens[0] == TRUNC:
            return {"role": "assistant", "content": bytes(tokens[1:]).decode()}, (
                ParseTermination.MALFORMED
            )
        content = bytes(tokens).decode()
        return {"role": "assistant", "content": content}, ParseTermination.STOP_SEQUENCE


def _enc(text: str, truncated: bool = False) -> list[int]:
    return ([TRUNC] if truncated else []) + list(text.encode())


@pytest.fixture(scope="module")
def traces():
    return {t.id: t for t in load_traces(FIX / "fixture_traces.jsonl")}


def _step(env, text, truncated=False):
    return asyncio.run(env.step(_enc(text, truncated)))


@pytest.mark.parametrize(
    "trace_id,response,truncated,reward,outcome_key",
    [
        ("fx-002", '{"action": "ASK", "rationale": "need approval"}', False, 1.0, "correct"),
        ("fx-002", '{"action": "ACT"}', False, -1.0, "premature_act"),
        ("fx-001", '{"action": "WAIT"}', False, -0.25, "missed_act"),
        ("fx-003", '{"action": "ASK"}', False, 0.0, "other_wrong"),
        ("fx-003", "I think we should wait.", False, -0.5, "invalid"),
        ("fx-003", '{"action": "WA', True, -0.5, "invalid"),
        # A complete answer is accepted even if the turn ended without the stop sequence.
        ("fx-003", '{"action": "WAIT"}', True, 1.0, "correct"),
    ],
)
def test_env_reward_and_metrics(traces, trace_id, response, truncated, reward, outcome_key):
    env = SteerBenchEnv(traces[trace_id], FakeRenderer(), PRESETS["asymmetric"])
    result = _step(env, response, truncated)
    assert result.reward == pytest.approx(reward)
    assert result.episode_done
    assert result.metrics[f"outcome/{outcome_key}"] == 1.0
    assert sum(v for k, v in result.metrics.items() if k.startswith("outcome/")) == 1.0


def test_env_prompt_has_system_and_situation_but_not_label(traces):
    t = traces["fx-004"]
    env = SteerBenchEnv(t, FakeRenderer(), PRESETS["symmetric"])
    obs, stop = asyncio.run(env.initial_observation())
    text = bytes(obs.to_ints()).decode()
    assert SYSTEM_PROMPT in text and t.observation in text
    assert t.rationale not in text
    assert stop == ["\n\nUser:"]


def test_symmetric_preset_rewards(traces):
    env = SteerBenchEnv(traces["fx-002"], FakeRenderer(), PRESETS["symmetric"])
    assert _step(env, '{"action": "ACT"}').reward == 0.0
    assert _step(env, "nonsense").reward == pytest.approx(-0.1)


def test_dataset_batches_and_groups(traces):
    ds = SteerBenchRLDataset(
        list(traces.values()),
        batch_size=5,
        group_size=4,
        renderer=FakeRenderer(),
        reward_config=PRESETS["asymmetric"],
    )
    assert len(ds) == 3  # ceil(12 / 5)
    seen = []
    for i in range(len(ds)):
        for builder in ds.get_batch(i):
            envs = asyncio.run(builder.make_envs())
            assert len(envs) == 4
            seen.append(envs[0].trace.id)
    assert sorted(seen) == sorted(traces)  # every trace exactly once per epoch


def test_scripted_policy_rollout(traces):
    """Drive every fixture through the env with a policy that always answers ASK and
    check the aggregate matches the reward table by hand."""
    total = 0.0
    for t in traces.values():
        env = SteerBenchEnv(t, FakeRenderer(), PRESETS["asymmetric"])
        asyncio.run(env.initial_observation())
        total += _step(env, '{"action": "ASK"}').reward
    golds = [t.gold_action for t in traces.values()]
    expected = golds.count("ASK") * 1.0 + golds.count("ACT") * -0.25
    assert total == pytest.approx(expected)


def test_decision_arm_builds_cookbook_decision(traces):
    pytest.importorskip("tinker_cookbook.recipes.decisions")
    from steerbench_tinker.decision_arm import trace_decision

    d = trace_decision(traces["fx-005"])
    assert d.labels == ["ACT", "ASK", "WAIT", "REMEMBER", "FORGET"]
    assert "vendor list v1" in d.text


def test_launch_configs_build_offline():
    from steerbench_tinker import train_rl, train_sft

    sft = train_sft.build_config_blueprint().make()
    assert sft.lora_rank == 16 and sft.num_epochs == 3
    rl = train_rl.build_config_blueprint().make()
    assert rl.dataset_builder.reward_preset == "asymmetric"
    assert rl.remove_constant_reward_groups
    assert rl.learning_rate < sft.learning_rate
    sym = (
        train_rl.build_config_blueprint()
        .apply({"dataset_builder.reward_preset": "symmetric"})
        .make()
    )
    assert sym.dataset_builder.reward_preset == "symmetric"
