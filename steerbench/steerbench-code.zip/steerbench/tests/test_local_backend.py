"""End-to-end tests of the local GPU backend on a tiny random model (CPU, offline)."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

pytest.importorskip("peft")

import torch

from steerbench_tinker import prepare_data
from steerbench_tinker.local import evaluate, hf, train_decision, train_rl, train_sft
from steerbench_tinker.schema import ACTIONS, read_normalized

FIX = Path(__file__).parent / "fixtures"


@pytest.fixture(scope="module")
def env(tmp_path_factory):
    root = tmp_path_factory.mktemp("local")
    from tests.tiny_model import build

    traces_text = (FIX / "fixture_traces.jsonl").read_text()
    model_dir = build(root / "tiny", corpus_extra=traces_text)
    prepare_data.main(
        [
            "--traces",
            str(FIX / "fixture_traces.jsonl"),
            "--out",
            str(root / "data"),
            "--test-fraction",
            "0.5",
        ]
    )
    return {"root": root, "model": str(model_dir), "data": root / "data"}


def _metrics(path: Path) -> dict:
    return json.loads((path / "metrics.json").read_text())


def test_letter_scores_cover_all_five_and_normalize(env):
    model, tok = hf.load(env["model"])
    t = read_normalized(env["data"] / "test.jsonl")[0]
    with torch.no_grad():
        scores = hf.label_logits(model, tok, [hf.decision_prompt(tok, t)] * 2)
    assert scores.shape == (2, 5)
    assert torch.allclose(scores[0], scores[1])  # same prompt, same scores, padding-safe
    probs = hf.probs_from_logits(scores[0])
    assert set(probs) == set(ACTIONS) and abs(sum(probs.values()) - 1) < 1e-4


def test_label_scoring_matches_unbatched(env):
    """Right-padding in a mixed-length batch must not change any prompt's scores."""
    model, tok = hf.load(env["model"])
    ts = read_normalized(env["data"] / "test.jsonl")[:3]
    prompts = [hf.decision_prompt(tok, t) for t in ts]
    with torch.no_grad():
        batched = hf.label_logits(model, tok, prompts)
        single = torch.cat([hf.label_logits(model, tok, [p]) for p in prompts])
    assert torch.allclose(batched, single, atol=1e-4)


@pytest.mark.parametrize("readout", ["generative", "decision"])
def test_evaluate_writes_standard_outputs(env, readout):
    out = env["root"] / f"zs_{readout}"
    evaluate.main(
        [
            "--readout",
            readout,
            "--out",
            str(out),
            "--model",
            env["model"],
            "--test-path",
            str(env["data"] / "test.jsonl"),
            "--batch-size",
            "4",
            "--max-new-tokens",
            "12",
        ]
    )
    m = _metrics(out)
    n = len(read_normalized(env["data"] / "test.jsonl"))
    view = m["strict"] if readout == "generative" else m["readout"]
    assert view["n"] == n
    rows = [json.loads(x) for x in (out / "predictions.jsonl").read_text().splitlines()]
    assert len(rows) == n
    meta = json.loads((out / "meta.json").read_text())
    assert meta["backend"] == "local-hf" and meta["test_sha256"]


def test_sft_then_eval_with_adapter(env):
    out = env["root"] / "sft"
    train_sft.main(
        [
            "--out",
            str(out),
            "--model",
            env["model"],
            "--train-path",
            str(env["data"] / "train.jsonl"),
            "--max-steps",
            "2",
            "--batch-size",
            "2",
            "--grad-accum",
            "1",
        ]
    )
    assert (out / "final" / "adapter_config.json").exists()
    ev = env["root"] / "sft_eval"
    evaluate.main(
        [
            "--readout",
            "generative",
            "--out",
            str(ev),
            "--model",
            env["model"],
            "--adapter",
            str(out / "final"),
            "--test-path",
            str(env["data"] / "test.jsonl"),
            "--max-new-tokens",
            "8",
        ]
    )
    assert _metrics(ev)["strict"]["n"] > 0


def test_grpo_from_sft_adapter(env):
    sft = env["root"] / "sft" / "final"
    if not sft.exists():
        pytest.skip("depends on test_sft_then_eval_with_adapter")
    out = env["root"] / "rl"
    train_rl.main(
        [
            "--out",
            str(out),
            "--model",
            env["model"],
            "--sft-adapter",
            str(sft),
            "--train-path",
            str(env["data"] / "train.jsonl"),
            "--num-generations",
            "4",
            "--prompts-per-step",
            "2",
            "--max-steps",
            "2",
            "--max-new-tokens",
            "8",
        ]
    )
    assert (out / "final" / "adapter_config.json").exists()
    logs = json.loads((out / "log_history.json").read_text())
    assert len(logs) == 2
    assert {"reward", "valid", "correct", "premature_act", "flat_groups"} <= set(logs[0])


def test_group_advantages_are_mean_centered():
    adv = train_rl.group_advantages([1.0, 0.0, -1.0, 1.0, 1.0, 1.0], 3)
    assert adv[:3] == [1.0, 0.0, -1.0]
    assert adv[3:] == [0.0, 0.0, 0.0]  # a flat group carries no signal


def test_sft_loss_masks_prompt_tokens(env):
    """Changing the prompt's last token must not change which tokens are scored."""
    from steerbench_tinker.local.train_common import sequence_logprobs

    model, tok = hf.load(env["model"])
    with torch.no_grad():
        lp, n = sequence_logprobs(
            model, [[5, 6, 7], [5, 6]], [[8, 9], [8, 9, 10]], tok.pad_token_id
        )
    assert n.tolist() == [2.0, 3.0]
    assert torch.isfinite(lp).all() and (lp < 0).all()


def test_decision_training_writes_eval(env):
    out = env["root"] / "decision"
    train_decision.main(
        [
            "--out",
            str(out),
            "--model",
            env["model"],
            "--train-path",
            str(env["data"] / "train.jsonl"),
            "--test-path",
            str(env["data"] / "test.jsonl"),
            "--max-steps",
            "2",
            "--batch-size",
            "2",
        ]
    )
    m = _metrics(out / "final_eval")
    assert "calibration" in m["readout"]
    assert (out / "final" / "adapter_config.json").exists()
