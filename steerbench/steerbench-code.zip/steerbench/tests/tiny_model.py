"""Build a tiny random Llama and a matching tokenizer entirely offline.

Used by the local-backend tests to push traces through every arm on CPU in seconds.
The model is untrained, so its outputs are noise; the point is that every code path
(generation, letter scoring, SFT, GRPO, decision training) runs and writes valid files.
"""

from __future__ import annotations

from pathlib import Path

from tokenizers import Tokenizer, decoders, models, pre_tokenizers, trainers
from transformers import LlamaConfig, LlamaForCausalLM, PreTrainedTokenizerFast

from steerbench_tinker.local.hf import DECISION_SYSTEM
from steerbench_tinker.prompt import JSON_INSTRUCTION, SYSTEM_PROMPT
from steerbench_tinker.schema import ACTION_DESCRIPTIONS

CHAT_TEMPLATE = (
    "{% for m in messages %}<|{{ m['role'] }}|>\n{{ m['content'] }}<|end|>\n{% endfor %}"
    "{% if add_generation_prompt %}<|assistant|>\n{% endif %}"
)
SPECIALS = ["<|pad|>", "<|end|>", "<|system|>", "<|user|>", "<|assistant|>"]


def build(out_dir: str | Path, corpus_extra: str = "") -> Path:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    corpus = [
        SYSTEM_PROMPT,
        JSON_INSTRUCTION,
        DECISION_SYSTEM,
        *ACTION_DESCRIPTIONS.values(),
        '{"action": "ACT", "rationale": "ok"} Answer: A B C D E',
        corpus_extra,
    ] * 20
    tk = Tokenizer(models.BPE(unk_token=None))
    tk.pre_tokenizer = pre_tokenizers.ByteLevel(add_prefix_space=False)
    tk.decoder = decoders.ByteLevel()
    tk.train_from_iterator(
        corpus,
        trainers.BpeTrainer(
            vocab_size=1200,
            special_tokens=SPECIALS,
            initial_alphabet=pre_tokenizers.ByteLevel.alphabet(),
        ),
    )
    tok = PreTrainedTokenizerFast(
        tokenizer_object=tk, pad_token="<|pad|>", eos_token="<|end|>", bos_token=None
    )
    tok.chat_template = CHAT_TEMPLATE
    tok.save_pretrained(out)
    cfg = LlamaConfig(
        vocab_size=len(tok),
        hidden_size=32,
        intermediate_size=64,
        num_hidden_layers=2,
        num_attention_heads=2,
        num_key_value_heads=2,
        max_position_embeddings=2048,
        pad_token_id=tok.pad_token_id,
        eos_token_id=tok.eos_token_id,
        bos_token_id=None,
        tie_word_embeddings=True,
    )
    LlamaForCausalLM(cfg).save_pretrained(out)
    return out
