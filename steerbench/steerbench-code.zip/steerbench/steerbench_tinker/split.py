"""Deterministic train/test split.

If every trace already carries a ``split`` of ``train`` or ``test`` (the original
2,000 / 500 SteerBench split), that split is kept. Otherwise traces are split
within each (gold action, domain) stratum by a hash of their id, so the split
does not depend on file order and each stratum gets its proportional share.
"""

from __future__ import annotations

import hashlib
from collections import defaultdict
from collections.abc import Sequence

from steerbench_tinker.schema import Trace


def _key(seed: int, trace_id: str) -> str:
    return hashlib.sha256(f"{seed}:{trace_id}".encode()).hexdigest()


def split_traces(
    traces: Sequence[Trace], test_fraction: float = 0.2, seed: int = 0
) -> tuple[list[Trace], list[Trace], str]:
    """Return ``(train, test, how)`` where ``how`` says which rule produced the split."""
    if traces and all(t.split in ("train", "test") for t in traces):
        train = [t for t in traces if t.split == "train"]
        test = [t for t in traces if t.split == "test"]
        return train, test, "existing split field"
    if not 0.0 < test_fraction < 1.0:
        raise ValueError("test_fraction must be in (0, 1)")

    strata: dict[tuple[str, str], list[Trace]] = defaultdict(list)
    for t in traces:
        strata[(t.gold_action, t.domain)].append(t)  # action first: even label coverage

    # Systematic sampling over traces ordered by stratum, then by id hash: every
    # stratum gets its proportional share (to within one trace) and the overall
    # test size is exactly floor(n * test_fraction), even when strata are tiny.
    ordered = [
        t for key in sorted(strata) for t in sorted(strata[key], key=lambda t: _key(seed, t.id))
    ]
    train: list[Trace] = []
    test: list[Trace] = []
    for i, t in enumerate(ordered):
        if int((i + 1) * test_fraction) > int(i * test_fraction):
            test.append(t)
        else:
            train.append(t)
    train.sort(key=lambda t: _key(seed + 1, t.id))
    test.sort(key=lambda t: t.id)
    return train, test, f"stratified hash split, test_fraction={test_fraction}, seed={seed}"
