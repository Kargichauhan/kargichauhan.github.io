"""Evaluate a generative policy (base model or a trained checkpoint) on the test traces.

    python -m steerbench_tinker.eval_generative out=results/zeroshot_llama1b
    python -m steerbench_tinker.eval_generative out=results/sft_llama1b \\
        checkpoint=tinker://.../sampler_weights/final

Writes ``predictions.jsonl`` (raw text plus strict and lenient parses for every
trace), ``metrics.json`` (both views) and ``meta.json``.
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
from pathlib import Path

import chz
import tinker
from tinker_cookbook import model_info, renderers
from tinker_cookbook.tokenizer_utils import get_tokenizer

from steerbench_tinker.metrics import compute
from steerbench_tinker.predictions import generative_row, to_scored, write_rows
from steerbench_tinker.prompt import SYSTEM_PROMPT, user_message
from steerbench_tinker.run_meta import file_sha256, write_meta
from steerbench_tinker.schema import Trace, read_normalized

logger = logging.getLogger(__name__)

DEFAULT_MODEL = "meta-llama/Llama-3.2-1B"


@chz.chz
class Config:
    out: str
    model_name: str = DEFAULT_MODEL
    checkpoint: str | None = None  # a tinker:// sampler path; None evaluates the base model
    renderer_name: str | None = None
    test_path: str = "data/test.jsonl"
    max_tokens: int = 128
    temperature: float = 0.0
    concurrency: int = 32
    limit: int | None = None  # evaluate only the first N traces (smoke tests)
    base_url: str | None = None


async def _sample_one(
    trace: Trace,
    client: tinker.SamplingClient,
    renderer: renderers.Renderer,
    cfg: Config,
    sem: asyncio.Semaphore,
) -> dict:
    convo: list[renderers.Message] = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": user_message(trace)},
    ]
    prompt = renderer.build_generation_prompt(convo)
    async with sem:
        for attempt in range(4):
            try:
                result = await client.sample_async(
                    prompt=prompt,
                    num_samples=1,
                    sampling_params=tinker.SamplingParams(
                        max_tokens=cfg.max_tokens,
                        temperature=cfg.temperature,
                        stop=renderer.get_stop_sequences(),
                    ),
                )
                break
            except Exception as e:  # transient API errors: back off and retry, then give up
                if attempt == 3:
                    raise
                wait = 2**attempt
                logger.warning("sample failed for %s (%s); retrying in %ss", trace.id, e, wait)
                await asyncio.sleep(wait)
    message, termination = renderer.parse_response(result.sequences[0].tokens)
    raw = renderers.get_text_content(message)
    return generative_row(trace, raw, truncated=not termination.is_clean)


async def run(cfg: Config) -> dict:
    traces = read_normalized(cfg.test_path)
    if cfg.limit is not None:
        traces = traces[: cfg.limit]
    renderer_name = cfg.renderer_name or model_info.get_recommended_renderer_name(cfg.model_name)
    renderer = renderers.get_renderer(renderer_name, tokenizer=get_tokenizer(cfg.model_name))
    service = tinker.ServiceClient(base_url=cfg.base_url)
    if cfg.checkpoint:
        client = service.create_sampling_client(
            model_path=cfg.checkpoint, base_model=cfg.model_name
        )
    else:
        client = service.create_sampling_client(base_model=cfg.model_name)

    start = time.time()
    sem = asyncio.Semaphore(cfg.concurrency)
    rows = await asyncio.gather(*(_sample_one(t, client, renderer, cfg, sem) for t in traces))
    elapsed = time.time() - start

    out = Path(cfg.out)
    write_rows(rows, out / "predictions.jsonl")
    metrics = {
        "arm": "generative",
        "strict": compute(to_scored(rows, "strict")),
        "lenient": compute(to_scored(rows, "lenient")),
        "truncated": sum(r["truncated"] for r in rows),
        "seconds": round(elapsed, 1),
    }
    (out / "metrics.json").write_text(json.dumps(metrics, indent=2) + "\n")
    write_meta(
        out,
        arm="generative",
        model_name=cfg.model_name,
        checkpoint=cfg.checkpoint,
        renderer_name=renderer_name,
        test_path=cfg.test_path,
        test_sha256=file_sha256(cfg.test_path),
        n=len(traces),
        sampling={"max_tokens": cfg.max_tokens, "temperature": cfg.temperature},
    )
    s, l_ = metrics["strict"], metrics["lenient"]
    print(
        f"{cfg.out}: strict acc {s['accuracy']:.3f} (parse {s['parse_rate']:.2f}) | "
        f"lenient acc {l_['accuracy']:.3f} | premature {s['premature_action_rate']} | "
        f"{elapsed:.0f}s"
    )
    return metrics


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    asyncio.run(run(chz.entrypoint(Config)))
