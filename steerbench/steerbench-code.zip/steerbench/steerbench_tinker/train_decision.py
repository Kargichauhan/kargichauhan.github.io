"""Train the decision readout with cross-entropy on the gold primitive (LoRA on Tinker).

    python -m steerbench_tinker.train_decision log_path=runs/decision_llama1b

One datum per trace and a single weighted answer token, so a step is far cheaper
than an SFT step on a full JSON answer or an RL step with eight rollouts. Test
accuracy, premature-action rate and calibration are logged at every evaluation.
"""

from __future__ import annotations

import asyncio
import json
import logging
import math
import random
import time
from pathlib import Path

import chz
import tinker
from tinker_cookbook import checkpoint_utils, cli_utils, hyperparam_utils, model_info, renderers
from tinker_cookbook.recipes.decisions import DecisionRenderer, decision_choice_datums
from tinker_cookbook.tokenizer_utils import get_tokenizer
from tinker_cookbook.utils import ml_log

from steerbench_tinker.decision_arm import trace_decision
from steerbench_tinker.eval_decision import score_traces
from steerbench_tinker.eval_generative import DEFAULT_MODEL
from steerbench_tinker.metrics import compute
from steerbench_tinker.predictions import to_scored, write_rows
from steerbench_tinker.run_meta import file_sha256, write_meta
from steerbench_tinker.schema import read_normalized

logger = logging.getLogger(__name__)


@chz.chz
class Config:
    log_path: str
    model_name: str = DEFAULT_MODEL
    renderer_name: str | None = None
    train_path: str = "data/train.jsonl"
    test_path: str = "data/test.jsonl"
    lora_rank: int = 16
    learning_rate: float | None = None  # default: hyperparam_utils.get_lr(model_name)
    batch_size: int = 32
    epochs: int = 3
    eval_every: int = 20
    seed: int = 0
    wandb_project: str | None = None
    behavior_if_log_dir_exists: cli_utils.LogdirBehavior = "ask"
    base_url: str | None = None


async def main(cfg: Config) -> None:
    cli_utils.check_log_dir(cfg.log_path, behavior_if_exists=cfg.behavior_if_log_dir_exists)
    ml_logger = ml_log.setup_logging(
        log_dir=cfg.log_path, wandb_project=cfg.wandb_project, config=cfg
    )
    train_traces = read_normalized(cfg.train_path)
    test_traces = read_normalized(cfg.test_path)
    random.Random(cfg.seed).shuffle(train_traces)
    lr = cfg.learning_rate or hyperparam_utils.get_lr(cfg.model_name)

    renderer_name = cfg.renderer_name or model_info.get_recommended_renderer_name(cfg.model_name)
    renderer = renderers.get_renderer(renderer_name, get_tokenizer(cfg.model_name))
    decision_renderer = DecisionRenderer(renderer)
    examples = [(trace_decision(t), t.gold_action) for t in train_traces]

    service = tinker.ServiceClient(base_url=cfg.base_url)
    training_client = await service.create_lora_training_client_async(
        base_model=cfg.model_name, rank=cfg.lora_rank, seed=cfg.seed
    )

    steps_per_epoch = math.ceil(len(examples) / cfg.batch_size)
    total_steps = steps_per_epoch * cfg.epochs
    history: list[dict] = []

    async def evaluate(step: int) -> None:
        client = await training_client.save_weights_and_get_sampling_client_async()
        rows = await score_traces(test_traces, client, decision_renderer)
        m = compute(to_scored(rows, "readout"), n_boot=500)
        entry = {
            "step": step,
            "accuracy": m["accuracy"],
            "premature_action_rate": m["premature_action_rate"],
            "brier": m["calibration"]["brier"],
            "ece": m["calibration"]["ece"],
        }
        history.append(entry)
        ml_logger.log_metrics({f"test/{k}": v for k, v in entry.items() if k != "step"}, step=step)
        if step == total_steps:
            out = Path(cfg.log_path) / "final_eval"
            write_rows(rows, out / "predictions.jsonl")
            (out / "metrics.json").write_text(
                json.dumps({"arm": "decision", "readout": m}, indent=2) + "\n"
            )

    await evaluate(0)
    for step in range(total_steps):
        t0 = time.time()
        offset = (step % steps_per_epoch) * cfg.batch_size
        batch = examples[offset : offset + cfg.batch_size]
        datums = decision_choice_datums(decision_renderer, batch)
        fwd = await training_client.forward_backward_async(datums, loss_fn="cross_entropy")
        opt = await training_client.optim_step_async(tinker.AdamParams(learning_rate=lr))
        fwd_result = await fwd.result_async()
        await opt.result_async()
        metrics = {f"train/{k}": v for k, v in fwd_result.metrics.items()}
        metrics.update(progress=(step + 1) / total_steps, time_step=time.time() - t0)
        ml_logger.log_metrics(metrics, step=step + 1)
        if step + 1 == total_steps or (cfg.eval_every and (step + 1) % cfg.eval_every == 0):
            await evaluate(step + 1)

    await checkpoint_utils.save_checkpoint_async(
        training_client,
        name="final",
        log_path=cfg.log_path,
        loop_state={"step": total_steps, "final": True},
        kind="both",
    )
    (Path(cfg.log_path) / "eval_history.json").write_text(json.dumps(history, indent=2) + "\n")
    write_meta(
        Path(cfg.log_path) / "final_eval",
        arm="decision_trained",
        model_name=cfg.model_name,
        renderer_name=renderer_name,
        lora_rank=cfg.lora_rank,
        learning_rate=lr,
        steps=total_steps,
        train_sha256=file_sha256(cfg.train_path),
        test_sha256=file_sha256(cfg.test_path),
    )
    ml_logger.close()


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    asyncio.run(main(chz.entrypoint(Config)))
