"""The decision-readout arm: SteerBench through the cookbook's ``decisions`` recipe.

Instead of generating JSON, the model is shown the five primitives as lettered
choices and scored on the logprob of each letter at a single answer position.
There is no output format to get wrong, so this arm measures the model's judgment
with formatting removed, and it yields a probability for every primitive, which
the generative arms cannot.
"""

from __future__ import annotations

from tinker_cookbook.recipes.decisions import Decision

from steerbench_tinker.prompt import situation_text
from steerbench_tinker.schema import ACTION_DESCRIPTIONS, ACTIONS, Trace


def trace_decision(trace: Trace) -> Decision:
    return Decision(
        situation_text(trace)
        + "\n\nWhich intervention should the agent take now? Choose ACT only when the task "
        "has everything it needs and acting is permitted.",
        [(a, ACTION_DESCRIPTIONS[a]) for a in ACTIONS],
    )
