"""Train the decision readout on your GPUs: cross-entropy over the five letter scores.

    python -m steerbench_tinker.local.train_decision --out runs/decision

The training objective scores the letters exactly the way ``evaluate --readout decision``
does, so what is trained is what is measured. Saves the adapter to ``<out>/final`` and
scores the test set into ``<out>/final_eval``.
"""

from __future__ import annotations

import argparse
import json
import random
import time
from pathlib import Path

import torch

from steerbench_tinker.local import hf
from steerbench_tinker.local.train_common import add_lora, amp_context
from steerbench_tinker.metrics import compute
from steerbench_tinker.predictions import decision_row, to_scored, write_rows
from steerbench_tinker.run_meta import file_sha256, write_meta
from steerbench_tinker.schema import ACTIONS, read_normalized


def main(argv: list[str] | None = None) -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--out", required=True)
    p.add_argument("--model", default=hf.DEFAULT_MODEL)
    p.add_argument("--train-path", default="data/train.jsonl")
    p.add_argument("--test-path", default="data/test.jsonl")
    p.add_argument("--epochs", type=int, default=2)
    p.add_argument("--batch-size", type=int, default=8)
    p.add_argument("--lr", type=float, default=1e-4)
    p.add_argument("--lora-rank", type=int, default=16)
    p.add_argument("--max-steps", type=int, default=None)
    p.add_argument("--seed", type=int, default=0)
    args = p.parse_args(argv)

    torch.manual_seed(args.seed)
    model, tok = hf.load(args.model, for_training=True)
    model = add_lora(model, args.lora_rank)
    model.print_trainable_parameters()
    train = read_normalized(args.train_path)
    test = read_normalized(args.test_path)
    target = {a: i for i, a in enumerate(ACTIONS)}
    opt = torch.optim.AdamW([p_ for p_ in model.parameters() if p_.requires_grad], lr=args.lr)
    dev = next(model.parameters()).device

    history, step = [], 0
    rng = random.Random(args.seed)
    model.train()
    t0 = time.time()
    for epoch in range(args.epochs):
        order = list(range(len(train)))
        rng.shuffle(order)
        for i in range(0, len(order), args.batch_size):
            batch = [train[j] for j in order[i : i + args.batch_size]]
            with amp_context():
                logits = hf.label_logits(model, tok, [hf.decision_prompt(tok, t) for t in batch])
            y = torch.tensor([target[t.gold_action] for t in batch], device=dev)
            loss = torch.nn.functional.cross_entropy(logits.float(), y)
            opt.zero_grad()
            loss.backward()
            opt.step()
            step += 1
            if step % 10 == 0:
                acc = (logits.argmax(-1) == y).float().mean().item()
                history.append({"step": step, "epoch": epoch, "loss": loss.item(), "acc": acc})
                print(f"step {step} loss {loss.item():.4f} batch-acc {acc:.2f}", flush=True)
            if args.max_steps and step >= args.max_steps:
                break
        if args.max_steps and step >= args.max_steps:
            break

    out = Path(args.out)
    final = out / "final"
    model.save_pretrained(str(final))
    tok.save_pretrained(str(final))
    (out / "train_history.json").write_text(json.dumps(history, indent=2) + "\n")

    model.eval()
    rows = []
    with torch.no_grad():
        for i in range(0, len(test), args.batch_size):
            batch = test[i : i + args.batch_size]
            with amp_context():
                scores = hf.label_logits(model, tok, [hf.decision_prompt(tok, t) for t in batch])
            rows += [decision_row(t, hf.probs_from_logits(s)) for t, s in zip(batch, scores)]
    ev = out / "final_eval"
    write_rows(rows, ev / "predictions.jsonl")
    metrics = {"arm": "decision", "readout": compute(to_scored(rows, "readout"))}
    (ev / "metrics.json").write_text(json.dumps(metrics, indent=2) + "\n")
    write_meta(
        ev,
        backend="local-hf",
        arm="decision_trained",
        model_name=args.model,
        checkpoint=str(final),
        lora_rank=args.lora_rank,
        learning_rate=args.lr,
        steps=step,
        train_sha256=file_sha256(args.train_path),
        test_sha256=file_sha256(args.test_path),
        seconds=round(time.time() - t0, 1),
    )
    m = metrics["readout"]
    print(f"decision (trained) acc {m['accuracy']:.3f} | premature {m['premature_action_rate']}")


if __name__ == "__main__":
    main()
