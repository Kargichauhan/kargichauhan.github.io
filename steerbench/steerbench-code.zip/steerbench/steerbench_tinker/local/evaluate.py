"""Evaluate a model on your GPUs, with either readout.

    python -m steerbench_tinker.local.evaluate --readout generative --out results/zs_gen
    python -m steerbench_tinker.local.evaluate --readout decision   --out results/zs_dec
    python -m steerbench_tinker.local.evaluate --readout generative --adapter runs/sft/final \\
        --out results/sft

Writes predictions.jsonl, metrics.json and meta.json in the same format as the Tinker
backend, so ``python -m steerbench_tinker.analyze`` works on either.
"""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import torch

from steerbench_tinker.local import hf
from steerbench_tinker.metrics import compute
from steerbench_tinker.predictions import decision_row, generative_row, to_scored, write_rows
from steerbench_tinker.run_meta import file_sha256, write_meta
from steerbench_tinker.schema import read_normalized


def run(args: argparse.Namespace) -> dict:
    traces = read_normalized(args.test_path)
    if args.limit:
        traces = traces[: args.limit]
    model, tok = hf.load(args.model, args.adapter)
    rows: list[dict] = []
    start = time.time()
    for i in range(0, len(traces), args.batch_size):
        batch = traces[i : i + args.batch_size]
        if args.readout == "generative":
            prompts = [hf.render(tok, hf.generative_messages(tok, t)) for t in batch]
            texts, trunc = hf.generate(model, tok, prompts, args.max_new_tokens)
            rows += [generative_row(t, x, truncated=tr) for t, x, tr in zip(batch, texts, trunc)]
        else:
            with torch.no_grad():
                scores = hf.label_logits(model, tok, [hf.decision_prompt(tok, t) for t in batch])
            rows += [decision_row(t, hf.probs_from_logits(s)) for t, s in zip(batch, scores)]
        print(f"  {min(i + args.batch_size, len(traces))}/{len(traces)}", flush=True)
    elapsed = time.time() - start

    out = Path(args.out)
    write_rows(rows, out / "predictions.jsonl")
    if args.readout == "generative":
        metrics = {
            "arm": "generative",
            "strict": compute(to_scored(rows, "strict")),
            "lenient": compute(to_scored(rows, "lenient")),
            "truncated": sum(r["truncated"] for r in rows),
        }
        s, l_ = metrics["strict"], metrics["lenient"]
        line = (
            f"strict acc {s['accuracy']:.3f} (parse {s['parse_rate']:.2f}) | "
            f"lenient acc {l_['accuracy']:.3f} | premature {s['premature_action_rate']}"
        )
    else:
        metrics = {"arm": "decision", "readout": compute(to_scored(rows, "readout"))}
        m = metrics["readout"]
        line = (
            f"decision acc {m['accuracy']:.3f} | premature {m['premature_action_rate']} | "
            f"brier {m['calibration']['brier']:.3f}"
        )
    metrics["seconds"] = round(elapsed, 1)
    (out / "metrics.json").write_text(json.dumps(metrics, indent=2) + "\n")
    write_meta(
        out,
        backend="local-hf",
        arm=args.readout,
        model_name=args.model,
        checkpoint=args.adapter,
        test_path=args.test_path,
        test_sha256=file_sha256(args.test_path),
        n=len(traces),
        sampling={"max_new_tokens": args.max_new_tokens, "greedy": True},
        gpu=torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
    )
    print(f"{args.out}: {line} | {elapsed:.0f}s")
    return metrics


def main(argv: list[str] | None = None) -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawTextHelpFormatter)
    p.add_argument("--readout", choices=("generative", "decision"), required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--model", default=hf.DEFAULT_MODEL)
    p.add_argument("--adapter", default=None, help="LoRA adapter directory from a training run")
    p.add_argument("--test-path", default="data/test.jsonl")
    p.add_argument("--batch-size", type=int, default=16)
    p.add_argument("--max-new-tokens", type=int, default=128)
    p.add_argument("--limit", type=int, default=None)
    run(p.parse_args(argv))


if __name__ == "__main__":
    main()
