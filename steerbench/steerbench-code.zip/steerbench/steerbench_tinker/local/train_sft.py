"""LoRA supervised fine-tuning on your GPUs.

    python -m steerbench_tinker.local.train_sft --out runs/sft

The loss is the negative log-likelihood of the assistant answer only (prompt tokens are
masked), averaged over answer tokens. The adapter is saved to ``<out>/final``.
"""

from __future__ import annotations

import argparse
import random
import time
from pathlib import Path

import torch

from steerbench_tinker.local import hf
from steerbench_tinker.local.train_common import (
    add_lora,
    amp_context,
    batches,
    optimizer_and_schedule,
    save_history,
    sequence_logprobs,
    steps_for,
)
from steerbench_tinker.prompt import target_completion
from steerbench_tinker.run_meta import file_sha256, write_meta
from steerbench_tinker.schema import read_normalized


def encode_examples(tok, traces, include_rationale: bool = True):
    """(prompt ids, answer ids + EOS) for each trace."""
    out = []
    for t in traces:
        prompt = tok(hf.render(tok, hf.generative_messages(tok, t)), add_special_tokens=False)
        answer = tok(target_completion(t, include_rationale), add_special_tokens=False)
        out.append((prompt.input_ids, answer.input_ids + [tok.eos_token_id]))
    return out


def main(argv: list[str] | None = None) -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--out", required=True)
    p.add_argument("--model", default=hf.DEFAULT_MODEL)
    p.add_argument("--train-path", default="data/train.jsonl")
    p.add_argument("--epochs", type=float, default=3)
    p.add_argument("--lr", type=float, default=2e-4)
    p.add_argument("--batch-size", type=int, default=8)
    p.add_argument("--grad-accum", type=int, default=4)
    p.add_argument("--lora-rank", type=int, default=16)
    p.add_argument("--max-steps", type=int, default=None)
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--no-rationale", action="store_true")
    args = p.parse_args(argv)

    torch.manual_seed(args.seed)
    model, tok = hf.load(args.model, for_training=True)
    model = add_lora(model, args.lora_rank)
    model.print_trainable_parameters()
    data = encode_examples(tok, read_normalized(args.train_path), not args.no_rationale)
    total = steps_for(len(data), args.batch_size, args.grad_accum, args.epochs)
    if args.max_steps:
        total = min(total, args.max_steps)
    opt, sched = optimizer_and_schedule(model, args.lr, total)

    rng = random.Random(args.seed)
    model.train()
    history, step, micro, t0 = [], 0, 0, time.time()
    running = []
    while step < total:
        order = data[:]
        rng.shuffle(order)
        for batch in batches(order, args.batch_size):
            with amp_context():
                lp, ntok = sequence_logprobs(
                    model, [b[0] for b in batch], [b[1] for b in batch], tok.pad_token_id
                )
            loss = -(lp.sum() / ntok.sum().clamp(min=1))
            (loss / args.grad_accum).backward()
            running.append(loss.item())
            micro += 1
            if micro % args.grad_accum:
                continue
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()
            sched.step()
            opt.zero_grad()
            step += 1
            if step % 10 == 0 or step == total:
                entry = {
                    "step": step,
                    "loss": sum(running) / len(running),
                    "lr": sched.get_last_lr()[0],
                }
                history.append(entry)
                print(f"step {step}/{total} loss {entry['loss']:.4f}", flush=True)
                running = []
            if step >= total:
                break

    final = Path(args.out) / "final"
    model.save_pretrained(str(final))
    tok.save_pretrained(str(final))
    save_history(args.out, history)
    write_meta(
        args.out,
        backend="local-hf",
        arm="sft",
        model_name=args.model,
        lora_rank=args.lora_rank,
        learning_rate=args.lr,
        epochs=args.epochs,
        steps=step,
        effective_batch=args.batch_size * args.grad_accum,
        train_sha256=file_sha256(args.train_path),
        seconds=round(time.time() - t0, 1),
    )
    print(f"saved adapter to {final}")


if __name__ == "__main__":
    main()
