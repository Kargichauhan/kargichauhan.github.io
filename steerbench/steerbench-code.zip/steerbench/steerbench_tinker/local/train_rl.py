"""Group-relative policy gradient (GRPO-style) on your GPUs, with the same reward presets
as the Tinker environment.

    python -m steerbench_tinker.local.train_rl --out runs/rl_asym --sft-adapter runs/sft/final
    python -m steerbench_tinker.local.train_rl --out runs/rl_sym  --sft-adapter runs/sft/final \\
        --reward symmetric

One step:
  1. take ``prompts_per_step`` training traces and sample ``num_generations`` answers each;
  2. score every answer with the reward preset (strict parse);
  3. advantage = reward minus the mean reward of its group (no std scaling); groups where
     every answer scored the same carry no signal and are skipped;
  4. loss = -sum(advantage * log p(answer)) / answer tokens, one gradient step.
Sampling and the update use the same weights, so this is the on-policy case where the
importance ratio is 1 (as in the Tinker cookbook's default loop).

Every step logs mean reward and the share of valid, correct and premature-ACT answers.
"""

from __future__ import annotations

import argparse
import random
import time
from pathlib import Path

import torch

from steerbench_tinker.local import hf
from steerbench_tinker.local.train_common import (
    add_lora,
    amp_context,
    batches,
    optimizer_and_schedule,
    save_history,
    sequence_logprobs,
)
from steerbench_tinker.parse import parse_strict
from steerbench_tinker.reward import PRESETS, score
from steerbench_tinker.run_meta import file_sha256, write_meta
from steerbench_tinker.schema import read_normalized


def group_advantages(rewards: list[float], group: int) -> list[float]:
    """Reward minus its group's mean, groups being consecutive runs of ``group`` items."""
    adv = []
    for g in range(0, len(rewards), group):
        chunk = rewards[g : g + group]
        mean = sum(chunk) / len(chunk)
        adv.extend(r - mean for r in chunk)
    return adv


@torch.no_grad()
def sample(model, tok, prompts: list[str], n: int, max_new_tokens: int, temperature: float):
    """``n`` sampled completions per prompt: (prompt ids, completion ids incl. EOS, text)."""
    tok.padding_side = "left"
    enc = tok(prompts, return_tensors="pt", padding=True, add_special_tokens=False)
    dev = next(model.parameters()).device
    out = model.generate(
        input_ids=enc.input_ids.to(dev),
        attention_mask=enc.attention_mask.to(dev),
        do_sample=True,
        temperature=temperature,
        top_p=1.0,
        top_k=0,
        max_new_tokens=max_new_tokens,
        num_return_sequences=n,
        pad_token_id=tok.pad_token_id,
    )
    width = enc.input_ids.shape[1]
    samples = []
    for i, row in enumerate(out.tolist()):
        src = i // n
        prompt_ids = [
            t for t, m in zip(enc.input_ids[src].tolist(), enc.attention_mask[src].tolist()) if m
        ]
        comp = row[width:]
        if tok.eos_token_id in comp:
            comp = comp[: comp.index(tok.eos_token_id) + 1]
        else:
            comp = [t for t in comp if t != tok.pad_token_id]
        samples.append((prompt_ids, comp, tok.decode(comp, skip_special_tokens=True)))
    return samples


def main(argv: list[str] | None = None) -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawTextHelpFormatter)
    p.add_argument("--out", required=True)
    p.add_argument("--model", default=hf.DEFAULT_MODEL)
    p.add_argument("--sft-adapter", default=None, help="start from this LoRA adapter")
    p.add_argument("--reward", choices=sorted(PRESETS), default="asymmetric")
    p.add_argument("--train-path", default="data/train.jsonl")
    p.add_argument("--num-generations", type=int, default=8)
    p.add_argument("--prompts-per-step", type=int, default=8)
    p.add_argument("--max-steps", type=int, default=200)
    p.add_argument("--lr", type=float, default=2e-5)
    p.add_argument("--lora-rank", type=int, default=16)
    p.add_argument("--max-new-tokens", type=int, default=128)
    p.add_argument("--temperature", type=float, default=1.0)
    p.add_argument("--micro-batch", type=int, default=16, help="completions per backward pass")
    p.add_argument("--save-every", type=int, default=50)
    p.add_argument("--seed", type=int, default=0)
    args = p.parse_args(argv)

    torch.manual_seed(args.seed)
    cfg = PRESETS[args.reward]
    model, tok = hf.load(args.model, args.sft_adapter, for_training=True)
    model = add_lora(model, args.lora_rank, dropout=0.0)
    model.print_trainable_parameters()
    traces = read_normalized(args.train_path)
    prompts = {t.id: hf.render(tok, hf.generative_messages(tok, t)) for t in traces}
    opt, sched = optimizer_and_schedule(model, args.lr, args.max_steps)
    rng = random.Random(args.seed)
    order: list = []
    history, t0 = [], time.time()

    for step in range(1, args.max_steps + 1):
        if len(order) < args.prompts_per_step:
            order = traces[:]
            rng.shuffle(order)
        batch, order = order[: args.prompts_per_step], order[args.prompts_per_step :]

        model.eval()
        samples = sample(
            model,
            tok,
            [prompts[t.id] for t in batch],
            args.num_generations,
            args.max_new_tokens,
            args.temperature,
        )
        rewards, kinds = [], []
        for i, (_, _, text) in enumerate(samples):
            r, kind = score(batch[i // args.num_generations].gold_action, parse_strict(text), cfg)
            rewards.append(r)
            kinds.append(kind)
        adv = group_advantages(rewards, args.num_generations)
        keep = [i for i, a in enumerate(adv) if a != 0.0 and len(samples[i][1]) > 0]

        model.train()
        loss_val = 0.0
        if keep:
            total_tokens = sum(len(samples[i][1]) for i in keep)
            for mb in batches(keep, args.micro_batch):
                with amp_context():
                    lp, _ = sequence_logprobs(
                        model,
                        [samples[i][0] for i in mb],
                        [samples[i][1] for i in mb],
                        tok.pad_token_id,
                    )
                a = torch.tensor([adv[i] for i in mb], device=lp.device)
                loss = -(a * lp).sum() / total_tokens
                loss.backward()
                loss_val += loss.item()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()
            opt.zero_grad()
            sched.step()  # the schedule advances only on steps that updated the weights

        n = len(kinds)
        groups = len(batch)
        flat = sum(
            1
            for g in range(groups)
            if len(set(rewards[g * args.num_generations : (g + 1) * args.num_generations])) == 1
        )
        entry = {
            "step": step,
            "reward": sum(rewards) / n,
            "valid": sum(k != "invalid" for k in kinds) / n,
            "correct": sum(k == "correct" for k in kinds) / n,
            "premature_act": sum(k == "premature_act" for k in kinds) / n,
            "flat_groups": flat / groups,
            "loss": loss_val,
            "mean_len": sum(len(s[1]) for s in samples) / n,
        }
        history.append(entry)
        print(
            f"step {step}/{args.max_steps} reward {entry['reward']:+.3f} valid {entry['valid']:.2f} "
            f"correct {entry['correct']:.2f} premature {entry['premature_act']:.2f} "
            f"flat {entry['flat_groups']:.2f}",
            flush=True,
        )
        if args.save_every and step % args.save_every == 0 and step < args.max_steps:
            model.save_pretrained(str(Path(args.out) / f"step_{step:05d}"))
            save_history(args.out, history)

    final = Path(args.out) / "final"
    model.save_pretrained(str(final))
    tok.save_pretrained(str(final))
    save_history(args.out, history)
    write_meta(
        args.out,
        backend="local-hf",
        arm=f"rl_{args.reward}",
        model_name=args.model,
        start_adapter=args.sft_adapter,
        reward=cfg.to_dict(),
        num_generations=args.num_generations,
        prompts_per_step=args.prompts_per_step,
        learning_rate=args.lr,
        steps=args.max_steps,
        train_sha256=file_sha256(args.train_path),
        seconds=round(time.time() - t0, 1),
    )
    print(f"saved adapter to {final}")


if __name__ == "__main__":
    main()
