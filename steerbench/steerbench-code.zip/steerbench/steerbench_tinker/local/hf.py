"""Shared Hugging Face helpers for running SteerBench on your own GPUs.

The prompt, parsers, reward and metrics are the same modules the Tinker backend
uses; only model loading, generation and scoring live here.
"""

from __future__ import annotations

import math
from collections.abc import Sequence

import torch
from jinja2 import TemplateError
from transformers import AutoModelForCausalLM, AutoTokenizer, PreTrainedTokenizerBase

from steerbench_tinker.prompt import SYSTEM_PROMPT, situation_text, user_message
from steerbench_tinker.schema import ACTION_DESCRIPTIONS, ACTIONS, Trace

DEFAULT_MODEL = "Qwen/Qwen2.5-1.5B-Instruct"
LETTERS = "ABCDE"
DECISION_SYSTEM = "You choose the intervention for an agent. Answer with the letter of one choice."


def device() -> str:
    return "cuda" if torch.cuda.is_available() else "cpu"


def load(model_name: str, adapter: str | None = None, *, for_training: bool = False):
    """Load a causal LM (bf16 on GPU) and its tokenizer; merge a LoRA adapter if given."""
    tok = AutoTokenizer.from_pretrained(model_name)
    if tok.pad_token is None:
        tok.pad_token = tok.eos_token
    on_gpu = torch.cuda.is_available()
    model = AutoModelForCausalLM.from_pretrained(
        model_name,
        dtype=torch.bfloat16 if on_gpu else torch.float32,
        device_map="auto" if on_gpu else None,
    )
    if adapter:
        from peft import PeftModel

        model = PeftModel.from_pretrained(model, adapter, is_trainable=for_training)
        if not for_training:
            model = model.merge_and_unload()
    if not for_training:
        model.eval()
    return model, tok


def _supports_system(tok: PreTrainedTokenizerBase) -> bool:
    try:
        tok.apply_chat_template(
            [{"role": "system", "content": "s"}, {"role": "user", "content": "u"}],
            tokenize=False,
            add_generation_prompt=True,
        )
        return True
    except (TemplateError, ValueError):  # templates reject a system turn by raising
        return False


def chat(tok: PreTrainedTokenizerBase, system: str, user: str) -> list[dict[str, str]]:
    """System + user turns, folded into one user turn if the template has no system role."""
    if _supports_system(tok):
        return [{"role": "system", "content": system}, {"role": "user", "content": user}]
    return [{"role": "user", "content": f"{system}\n\n{user}"}]


def generative_messages(tok: PreTrainedTokenizerBase, trace: Trace) -> list[dict[str, str]]:
    return chat(tok, SYSTEM_PROMPT, user_message(trace))


def render(tok: PreTrainedTokenizerBase, messages: list[dict[str, str]]) -> str:
    text = tok.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
    assert isinstance(text, str)
    return text


# ---------------------------------------------------------------- decision readout
def decision_prompt(tok: PreTrainedTokenizerBase, trace: Trace) -> str:
    choices = "\n".join(f"{L}) {a}: {ACTION_DESCRIPTIONS[a]}" for L, a in zip(LETTERS, ACTIONS))
    user = (
        f"{situation_text(trace)}\n\nWhich intervention should the agent take now? Choose ACT "
        f"only when the task has everything it needs and acting is permitted.\n\n{choices}\n\n"
        "Answer with the letter only."
    )
    return render(tok, chat(tok, DECISION_SYSTEM, user)) + "Answer:"


def _common_prefix(a: Sequence[int], b: Sequence[int]) -> int:
    n = 0
    for x, y in zip(a, b):
        if x != y:
            break
        n += 1
    return n


def label_batch(tok: PreTrainedTokenizerBase, prompts: Sequence[str]):
    """Every prompt continued with each of " A".." E", right-padded, plus the span of
    continuation tokens to score in each row. Scoring the tokens that differ from the bare
    prompt keeps the comparison fair even when a letter merges with the preceding text."""
    rows, spans = [], []
    for p in prompts:
        base = tok(p, add_special_tokens=False).input_ids
        for L in LETTERS:
            full = tok(p + " " + L, add_special_tokens=False).input_ids
            k = min(_common_prefix(base, full), len(full) - 1)
            rows.append(full)
            spans.append((k, len(full)))
    width = max(len(r) for r in rows)
    pad = tok.pad_token_id
    ids = torch.full((len(rows), width), pad, dtype=torch.long)
    mask = torch.zeros((len(rows), width), dtype=torch.long)
    for i, r in enumerate(rows):
        ids[i, : len(r)] = torch.tensor(r)
        mask[i, : len(r)] = 1
    return ids, mask, spans


def label_logits(model, tok: PreTrainedTokenizerBase, prompts: Sequence[str]) -> torch.Tensor:
    """Log-likelihood of each letter for each prompt: tensor [len(prompts), 5]."""
    ids, mask, spans = label_batch(tok, prompts)
    dev = next(model.parameters()).device
    ids, mask = ids.to(dev), mask.to(dev)
    logits = model(input_ids=ids, attention_mask=mask).logits.float()
    logp = torch.log_softmax(logits[:, :-1], dim=-1)
    tok_lp = logp.gather(-1, ids[:, 1:].unsqueeze(-1)).squeeze(-1)  # [rows, width-1]
    scores = torch.stack([tok_lp[i, k - 1 : end - 1].sum() for i, (k, end) in enumerate(spans)])
    return scores.view(len(prompts), len(LETTERS))


def probs_from_logits(row: torch.Tensor) -> dict[str, float]:
    p = torch.softmax(row.float(), dim=-1).tolist()
    assert math.isclose(sum(p), 1.0, rel_tol=1e-4)
    return dict(zip(ACTIONS, p))


# ---------------------------------------------------------------- generation
@torch.no_grad()
def generate(model, tok: PreTrainedTokenizerBase, prompts: Sequence[str], max_new_tokens: int):
    """Greedy decode a batch. Returns (texts, truncated flags)."""
    tok.padding_side = "left"
    enc = tok(list(prompts), return_tensors="pt", padding=True, add_special_tokens=False)
    dev = next(model.parameters()).device
    enc = {k: v.to(dev) for k, v in enc.items()}
    out = model.generate(
        **enc,
        max_new_tokens=max_new_tokens,
        do_sample=False,
        pad_token_id=tok.pad_token_id,
    )
    new = out[:, enc["input_ids"].shape[1] :]
    texts, truncated = [], []
    eos = {tok.eos_token_id}
    cfg_eos = getattr(model.generation_config, "eos_token_id", None)
    if isinstance(cfg_eos, int):
        eos.add(cfg_eos)
    elif cfg_eos:
        eos.update(cfg_eos)
    for row in new.tolist():
        ended = any(t in eos for t in row)
        texts.append(tok.decode(row, skip_special_tokens=True))
        truncated.append(not ended and len(row) >= max_new_tokens)
    return texts, truncated
