"""Small training utilities shared by the local SFT, RL and decision loops.

Written out by hand (no trainer framework) so every step of each algorithm is visible
and the whole backend runs, and is tested, on CPU as well as GPU.
"""

from __future__ import annotations

import json
import math
from collections.abc import Sequence
from contextlib import nullcontext
from pathlib import Path

import torch
from peft import LoraConfig, PeftModel, get_peft_model


def amp_context():
    if torch.cuda.is_available():
        return torch.autocast("cuda", dtype=torch.bfloat16)
    return nullcontext()


def add_lora(model, rank: int, dropout: float = 0.05):
    if isinstance(model, PeftModel):
        return model  # already carries a (trainable) adapter, e.g. from SFT
    return get_peft_model(
        model,
        LoraConfig(
            r=rank,
            lora_alpha=2 * rank,
            lora_dropout=dropout,
            target_modules="all-linear",
            task_type="CAUSAL_LM",
        ),
    )


def optimizer_and_schedule(model, lr: float, total_steps: int, warmup_frac: float = 0.03):
    params = [p for p in model.parameters() if p.requires_grad]
    opt = torch.optim.AdamW(params, lr=lr, weight_decay=0.0)
    warm = max(1, int(total_steps * warmup_frac))

    def factor(step: int) -> float:
        if step < warm:
            return (step + 1) / warm
        return max(0.0, (total_steps - step) / max(1, total_steps - warm))

    return opt, torch.optim.lr_scheduler.LambdaLR(opt, factor)


def sequence_logprobs(
    model,
    prompts: Sequence[Sequence[int]],
    targets: Sequence[Sequence[int]],
    pad_id: int,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Sum of log p(target | prompt) per row, and the number of target tokens per row.

    Rows are right-padded; only target positions contribute, so padding and prompt
    tokens never enter the loss.
    """
    rows = [list(p) + list(t) for p, t in zip(prompts, targets)]
    width = max(len(r) for r in rows)
    dev = next(model.parameters()).device
    ids = torch.full((len(rows), width), pad_id, dtype=torch.long)
    attn = torch.zeros_like(ids)
    tmask = torch.zeros_like(ids, dtype=torch.float)
    for i, (p, t) in enumerate(zip(prompts, targets)):
        n = len(p) + len(t)
        ids[i, :n] = torch.tensor(rows[i])
        attn[i, :n] = 1
        tmask[i, len(p) : n] = 1.0
    ids, attn, tmask = ids.to(dev), attn.to(dev), tmask.to(dev)
    logits = model(input_ids=ids, attention_mask=attn).logits.float()
    logp = torch.log_softmax(logits[:, :-1], dim=-1)
    tok_lp = logp.gather(-1, ids[:, 1:].unsqueeze(-1)).squeeze(-1) * tmask[:, 1:]
    return tok_lp.sum(-1), tmask[:, 1:].sum(-1)


def save_history(out_dir: str | Path, history: list[dict]) -> None:
    Path(out_dir).mkdir(parents=True, exist_ok=True)
    (Path(out_dir) / "log_history.json").write_text(json.dumps(history, indent=2) + "\n")


def batches(items: Sequence, size: int):
    for i in range(0, len(items), size):
        yield items[i : i + size]


def steps_for(n_items: int, batch: int, accum: int, epochs: float) -> int:
    return max(1, math.ceil(n_items / (batch * accum) * epochs))
