"""Prediction files: one JSON line per trace, raw output kept next to both parses.

Keeping the raw text means any run can be re-scored later with a different
parser or reward without paying for sampling again.
"""

from __future__ import annotations

import json
from collections.abc import Iterable, Mapping
from pathlib import Path
from typing import Any

from steerbench_tinker.metrics import Scored
from steerbench_tinker.parse import parse_lenient, parse_strict
from steerbench_tinker.schema import ACTIONS, Trace


def generative_row(trace: Trace, raw: str, *, truncated: bool = False) -> dict[str, Any]:
    strict = parse_strict(raw)
    lenient = parse_lenient(raw)
    strict_status = "truncated" if truncated and not strict.ok else strict.status.value
    return {
        "id": trace.id,
        "domain": trace.domain,
        "gold": trace.gold_action,
        "raw": raw,
        "truncated": truncated,
        "strict": {"status": strict_status, "action": strict.action},
        "lenient": {"status": lenient.status.value, "action": lenient.action},
    }


def decision_row(trace: Trace, probs: Mapping[str, float]) -> dict[str, Any]:
    pred = max(ACTIONS, key=lambda a: probs.get(a, 0.0))
    return {
        "id": trace.id,
        "domain": trace.domain,
        "gold": trace.gold_action,
        "probs": {a: float(probs.get(a, 0.0)) for a in ACTIONS},
        "readout": {"status": "ok", "action": pred},
    }


def write_rows(rows: Iterable[Mapping[str, Any]], path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")


def read_rows(path: str | Path) -> list[dict[str, Any]]:
    with Path(path).open(encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def to_scored(rows: Iterable[Mapping[str, Any]], view: str) -> list[Scored]:
    """``view`` is ``strict`` or ``lenient`` for generative rows, ``readout`` for decision rows."""
    out = []
    for r in rows:
        if view not in r:
            raise KeyError(f"row {r.get('id')} has no {view!r} view; available: {sorted(r)}")
        v = r[view]
        out.append(
            Scored(
                id=str(r["id"]),
                domain=r["domain"],
                gold=r["gold"],
                pred=v["action"] if v["status"] == "ok" else None,
                status=v["status"],
                probs=r.get("probs"),
            )
        )
    return out
