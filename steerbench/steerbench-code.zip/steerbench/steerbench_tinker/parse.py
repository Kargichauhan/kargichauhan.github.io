"""Two parsers for a model's decision, so format failures and judgment failures
can be counted separately.

* ``strict``: the whole response (optionally inside one ```json fence) must be a
  single JSON object whose ``action`` is one of the five primitives. This is what
  the RL reward and the headline numbers use.
* ``lenient``: recover the decision if it is recoverable at all: the first JSON
  object anywhere in the text, else a single unambiguous primitive keyword. This is
  a diagnostic: lenient accuracy minus strict accuracy is the share of errors that
  are only formatting.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from enum import Enum

from steerbench_tinker.schema import ACTIONS, normalize_action


class ParseStatus(str, Enum):
    OK = "ok"
    EMPTY = "empty"
    NO_JSON = "no_json"
    INVALID_JSON = "invalid_json"
    MISSING_ACTION = "missing_action"
    UNKNOWN_ACTION = "unknown_action"
    AMBIGUOUS = "ambiguous"
    TRUNCATED = "truncated"


@dataclass(frozen=True)
class ParseResult:
    status: ParseStatus
    action: str | None = None

    @property
    def ok(self) -> bool:
        return self.status is ParseStatus.OK


_FENCE = re.compile(r"^```(?:json)?\s*(.*?)\s*```$", re.DOTALL | re.IGNORECASE)
_KEYWORD = re.compile(r"\b(" + "|".join(ACTIONS) + r")\b")


def _from_object(obj: object) -> ParseResult:
    if not isinstance(obj, dict):
        return ParseResult(ParseStatus.INVALID_JSON)
    if "action" not in obj:
        return ParseResult(ParseStatus.MISSING_ACTION)
    action = normalize_action(obj["action"])
    if action is None:
        return ParseResult(ParseStatus.UNKNOWN_ACTION)
    return ParseResult(ParseStatus.OK, action)


def parse_strict(text: str) -> ParseResult:
    body = text.strip()
    if not body:
        return ParseResult(ParseStatus.EMPTY)
    fenced = _FENCE.match(body)
    if fenced:
        body = fenced.group(1).strip()
    if not body.startswith("{"):
        return ParseResult(ParseStatus.NO_JSON)
    try:
        obj = json.loads(body)
    except json.JSONDecodeError:
        return ParseResult(ParseStatus.INVALID_JSON)
    return _from_object(obj)


def parse_lenient(text: str) -> ParseResult:
    strict = parse_strict(text)
    if strict.ok:
        return strict
    body = text.strip()
    if not body:
        return ParseResult(ParseStatus.EMPTY)

    decoder = json.JSONDecoder()
    saw_json = False
    for match in re.finditer(r"\{", body):
        try:
            obj, _ = decoder.raw_decode(body, match.start())
        except json.JSONDecodeError:
            continue
        saw_json = True
        result = _from_object(obj)
        if result.ok:
            return result

    # Fall back to a bare keyword, accepted only when exactly one primitive is named.
    named = {m.group(1) for m in _KEYWORD.finditer(body.upper())}
    if len(named) == 1:
        return ParseResult(ParseStatus.OK, named.pop())
    if len(named) > 1:
        return ParseResult(ParseStatus.AMBIGUOUS)
    return ParseResult(ParseStatus.INVALID_JSON if saw_json else ParseStatus.NO_JSON)


def parse(text: str, mode: str = "strict") -> ParseResult:
    if mode == "strict":
        return parse_strict(text)
    if mode == "lenient":
        return parse_lenient(text)
    raise ValueError(f"unknown parse mode {mode!r}")
