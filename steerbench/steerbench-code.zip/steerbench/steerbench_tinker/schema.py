"""SteerBench trace schema and a tolerant loader for existing trace files.

A trace is one decision point for an agent: a task, a scoped memory block, an
observation, and the single correct intervention primitive.

Existing SteerBench files may use different field names. ``load_traces`` looks
fields up through ``FIELD_ALIASES`` (first match wins) and accepts an explicit
``field_map`` for anything the aliases miss, e.g. ``{"gold_action": "label.action"}``.
Dotted paths reach into nested objects.
"""

from __future__ import annotations

import json
from collections.abc import Iterable, Mapping
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

ACTIONS: tuple[str, ...] = ("ACT", "ASK", "WAIT", "REMEMBER", "FORGET")

ACTION_DESCRIPTIONS: dict[str, str] = {
    "ACT": "Proceed autonomously with the next step of the task.",
    "ASK": "Stop and ask the human for missing information or permission.",
    "WAIT": "Hold off until a pending result or verification arrives.",
    "REMEMBER": "Store a durable fact from the observation in memory.",
    "FORGET": "Remove stale or superseded information from memory.",
}

FIELD_ALIASES: dict[str, tuple[str, ...]] = {
    "id": ("id", "trace_id", "uid", "example_id"),
    "domain": ("domain", "category", "task_domain"),
    "task": ("task", "task_context", "goal", "instruction", "context"),
    "observation": ("observation", "obs", "current_observation", "state"),
    "memory": ("memory", "scoped_memory", "memory_block", "memories"),
    "gold_action": (
        "gold_action",
        "action",
        "label",
        "gold",
        "expected_action",
        "target_action",
        "gold.action",
        "label.action",
    ),
    "rationale": ("rationale", "gold_rationale", "explanation", "gold.rationale"),
    "split": ("split",),
}

REQUIRED = ("id", "domain", "task", "observation", "gold_action")


class TraceFormatError(ValueError):
    """Raised when a trace record cannot be mapped onto the schema."""


@dataclass(frozen=True)
class Trace:
    id: str
    domain: str
    task: str
    observation: str
    gold_action: str
    memory: tuple[str, ...] = field(default_factory=tuple)
    rationale: str | None = None
    split: str | None = None

    def to_json(self) -> dict[str, Any]:
        d = asdict(self)
        d["memory"] = list(self.memory)
        return d

    @classmethod
    def from_json(cls, d: Mapping[str, Any]) -> Trace:
        return cls(
            id=str(d["id"]),
            domain=str(d["domain"]),
            task=str(d["task"]),
            observation=str(d["observation"]),
            gold_action=str(d["gold_action"]),
            memory=tuple(d.get("memory") or ()),
            rationale=d.get("rationale"),
            split=d.get("split"),
        )


def _get_path(record: Mapping[str, Any], path: str) -> Any:
    cur: Any = record
    for part in path.split("."):
        if not isinstance(cur, Mapping) or part not in cur:
            return None
        cur = cur[part]
    return cur


def _lookup(record: Mapping[str, Any], name: str, field_map: Mapping[str, str]) -> Any:
    if name in field_map:
        return _get_path(record, field_map[name])
    for alias in FIELD_ALIASES[name]:
        value = _get_path(record, alias)
        if value is not None:
            return value
    return None


def normalize_action(value: Any) -> str | None:
    """Map a raw label onto one of ``ACTIONS``; ``None`` if it is not one."""
    if isinstance(value, Mapping):
        value = value.get("action")
    if not isinstance(value, str):
        return None
    label = value.strip().strip("\"'").upper()
    return label if label in ACTIONS else None


def _normalize_memory(value: Any) -> tuple[str, ...]:
    if value is None or value == "":
        return ()
    if isinstance(value, str):
        lines = [ln.strip(" -*\t") for ln in value.splitlines()]
        return tuple(ln for ln in lines if ln)
    if isinstance(value, Mapping):
        return tuple(f"{k}: {v}" for k, v in value.items())
    if isinstance(value, Iterable):
        out = []
        for item in value:
            if isinstance(item, Mapping):
                text = item.get("content") or item.get("text") or json.dumps(item, sort_keys=True)
                out.append(str(text))
            else:
                out.append(str(item))
        return tuple(out)
    return (str(value),)


def record_to_trace(
    record: Mapping[str, Any], field_map: Mapping[str, str] | None = None, *, where: str = ""
) -> Trace:
    field_map = field_map or {}
    values = {name: _lookup(record, name, field_map) for name in FIELD_ALIASES}
    missing = [name for name in REQUIRED if values[name] in (None, "")]
    if missing:
        raise TraceFormatError(
            f"{where}missing {missing}; record keys are {sorted(record.keys())}. "
            "Pass --map <field>=<key> to point at the right key."
        )
    action = normalize_action(values["gold_action"])
    if action is None:
        raise TraceFormatError(
            f"{where}gold action {values['gold_action']!r} is not one of {list(ACTIONS)}"
        )
    split = values["split"]
    if split is not None:
        split = str(split).lower()
        split = {"held-out": "test", "heldout": "test", "eval": "test", "dev": "test"}.get(
            split, split
        )
    return Trace(
        id=str(values["id"]),
        domain=str(values["domain"]).strip().lower().replace(" ", "_"),
        task=str(values["task"]).strip(),
        observation=str(values["observation"]).strip(),
        gold_action=action,
        memory=_normalize_memory(values["memory"]),
        rationale=(str(values["rationale"]).strip() if values["rationale"] else None),
        split=split,
    )


def load_traces(path: str | Path, field_map: Mapping[str, str] | None = None) -> list[Trace]:
    """Load traces from a JSONL file or a JSON file holding a list (or ``{"traces": [...]}``)."""
    path = Path(path)
    text = path.read_text(encoding="utf-8")
    records: list[tuple[str, Mapping[str, Any]]] = []
    whole: Any = None
    if path.suffix != ".jsonl":
        try:
            whole = json.loads(text)
        except json.JSONDecodeError:
            whole = None  # not a single JSON document: treat as JSONL
    if whole is not None:
        data = whole
        if isinstance(data, Mapping):
            data = data.get("traces") or data.get("data") or data.get("examples") or [data]
        records = [(f"{path.name}[{i}]: ", r) for i, r in enumerate(data)]
    else:
        for lineno, line in enumerate(text.splitlines(), start=1):
            if not line.strip():
                continue
            try:
                records.append((f"{path.name}:{lineno}: ", json.loads(line)))
            except json.JSONDecodeError as e:
                raise TraceFormatError(f"{path.name}:{lineno}: invalid JSON ({e.msg})") from e

    traces = [record_to_trace(r, field_map, where=where) for where, r in records]
    seen: set[str] = set()
    for t in traces:
        if t.id in seen:
            raise TraceFormatError(f"duplicate trace id {t.id!r} in {path.name}")
        seen.add(t.id)
    return traces


def write_traces(traces: Iterable[Trace], path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        for t in traces:
            f.write(json.dumps(t.to_json(), ensure_ascii=False) + "\n")


def read_normalized(path: str | Path) -> list[Trace]:
    """Read a file written by ``write_traces``."""
    with Path(path).open(encoding="utf-8") as f:
        return [Trace.from_json(json.loads(line)) for line in f if line.strip()]
