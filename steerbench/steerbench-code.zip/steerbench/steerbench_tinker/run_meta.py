"""Run metadata written next to every result, so a number on the site can be traced
back to the exact model, checkpoint, prompt and data it came from."""

from __future__ import annotations

import hashlib
import json
import platform
import subprocess
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from steerbench_tinker.prompt import JSON_INSTRUCTION, SYSTEM_PROMPT


def file_sha256(path: str | Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def prompt_sha256() -> str:
    return hashlib.sha256((SYSTEM_PROMPT + "\n" + JSON_INSTRUCTION).encode()).hexdigest()


def git_rev() -> str | None:
    try:
        out = subprocess.run(
            ["git", "rev-parse", "--short", "HEAD"],
            capture_output=True,
            text=True,
            check=True,
            cwd=Path(__file__).resolve().parent,
        )
        return out.stdout.strip() or None
    except (OSError, subprocess.CalledProcessError):
        return None


def write_meta(out_dir: str | Path, **fields: Any) -> dict[str, Any]:
    meta = {
        "created_utc": datetime.now(UTC).isoformat(timespec="seconds"),
        "git_rev": git_rev(),
        "prompt_sha256": prompt_sha256(),
        "python": platform.python_version(),
        **fields,
    }
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    (out / "meta.json").write_text(json.dumps(meta, indent=2, default=str) + "\n")
    return meta
