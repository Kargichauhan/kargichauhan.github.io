"""Reward for one decision, with every component reported separately.

Two presets are compared in the RL ablation:

* ``symmetric``: 1 for the right primitive, 0 for any other valid primitive, and a
  small penalty for an unparseable answer. Every mistake costs the same.
* ``asymmetric``: acting when the agent should have asked, waited or touched
  memory (a *premature action*) is the most expensive mistake. Being too cautious
  when acting was right (a *missed action*) costs a little. An unparseable answer
  sits between the two, and is always worse than any valid non-ACT answer, so the
  policy can never improve its reward by emitting garbage when it is unsure
  (``tests/test_reward.py`` checks this property for every preset).
"""

from __future__ import annotations

from dataclasses import asdict, dataclass

from steerbench_tinker.parse import ParseResult


@dataclass(frozen=True)
class RewardConfig:
    correct: float = 1.0
    premature_act: float = 0.0  # predicted ACT, gold is not ACT
    missed_act: float = 0.0  # gold is ACT, predicted another valid primitive
    other_wrong: float = 0.0  # wrong, and neither of the above
    invalid: float = -0.1  # unparseable / truncated

    def to_dict(self) -> dict[str, float]:
        return asdict(self)


PRESETS: dict[str, RewardConfig] = {
    "symmetric": RewardConfig(),
    "asymmetric": RewardConfig(
        correct=1.0, premature_act=-1.0, missed_act=-0.25, other_wrong=0.0, invalid=-0.5
    ),
}


def outcome(gold: str, pred: str | None) -> str:
    """Classify a decision: correct, premature_act, missed_act, other_wrong or invalid."""
    if pred is None:
        return "invalid"
    if pred == gold:
        return "correct"
    if pred == "ACT":
        return "premature_act"
    if gold == "ACT":
        return "missed_act"
    return "other_wrong"


def score(gold: str, parsed: ParseResult, config: RewardConfig) -> tuple[float, str]:
    kind = outcome(gold, parsed.action if parsed.ok else None)
    return getattr(config, kind), kind
