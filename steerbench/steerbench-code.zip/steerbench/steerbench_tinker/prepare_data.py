"""Validate SteerBench traces, split them, and write every file the arms consume.

    python -m steerbench_tinker.prepare_data --traces path/to/traces.jsonl --out data/

Writes ``train.jsonl`` / ``test.jsonl`` (normalized traces), ``sft_train.jsonl`` /
``sft_test.jsonl`` (chat conversations for supervised fine-tuning) and
``data_card.json`` (counts per domain and gold action, file hashes, split rule).
"""

from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path

from steerbench_tinker.prompt import sft_conversation
from steerbench_tinker.run_meta import file_sha256
from steerbench_tinker.schema import ACTIONS, Trace, load_traces, write_traces
from steerbench_tinker.split import split_traces


def _counts(traces: list[Trace]) -> dict:
    by_action = Counter(t.gold_action for t in traces)
    by_domain = Counter(t.domain for t in traces)
    cross = Counter((t.domain, t.gold_action) for t in traces)
    return {
        "n": len(traces),
        "by_action": {a: by_action.get(a, 0) for a in ACTIONS},
        "by_domain": dict(sorted(by_domain.items())),
        "by_domain_action": {
            d: {a: cross.get((d, a), 0) for a in ACTIONS} for d in sorted(by_domain)
        },
        "with_rationale": sum(1 for t in traces if t.rationale),
    }


def main(argv: list[str] | None = None) -> dict:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawTextHelpFormatter)
    p.add_argument("--traces", required=True, help="JSONL or JSON file of SteerBench traces")
    p.add_argument("--out", default="data", help="output directory")
    p.add_argument("--test-fraction", type=float, default=0.2)
    p.add_argument("--seed", type=int, default=0)
    p.add_argument(
        "--map",
        action="append",
        default=[],
        metavar="FIELD=KEY",
        help="map a schema field onto a key in your file, e.g. --map gold_action=label.action",
    )
    p.add_argument("--no-rationale", action="store_true", help="SFT targets carry only the action")
    args = p.parse_args(argv)

    field_map = dict(m.split("=", 1) for m in args.map)
    traces = load_traces(args.traces, field_map)
    train, test, how = split_traces(traces, args.test_fraction, args.seed)
    train_ids = {t.id for t in train}
    leaked = [t.id for t in test if t.id in train_ids]
    if leaked:
        raise SystemExit(f"split error: {len(leaked)} ids in both train and test")

    out = Path(args.out)
    write_traces(train, out / "train.jsonl")
    write_traces(test, out / "test.jsonl")
    for name, split in (("sft_train.jsonl", train), ("sft_test.jsonl", test)):
        with (out / name).open("w", encoding="utf-8") as f:
            for t in split:
                conv = sft_conversation(t, include_rationale=not args.no_rationale)
                f.write(json.dumps(conv, ensure_ascii=False) + "\n")

    missing_in_test = [a for a in ACTIONS if not any(t.gold_action == a for t in test)]
    card = {
        "source": str(Path(args.traces).resolve()),
        "source_sha256": file_sha256(args.traces),
        "split_rule": how,
        "train": _counts(train),
        "test": _counts(test),
        "warnings": (
            [f"no test traces with gold action {missing_in_test}"] if missing_in_test else []
        ),
        "files_sha256": {
            name: file_sha256(out / name)
            for name in ("train.jsonl", "test.jsonl", "sft_train.jsonl", "sft_test.jsonl")
        },
    }
    (out / "data_card.json").write_text(json.dumps(card, indent=2) + "\n")
    print(f"{len(traces)} traces -> train {len(train)} / test {len(test)} ({how}); wrote {out}/")
    for w in card["warnings"]:
        print("WARNING:", w)
    return card


if __name__ == "__main__":
    main()
