"""Metrics over a set of scored decisions.

Definitions (all fractions in [0, 1]):

* ``accuracy``: right primitive, counting unparseable answers as wrong.
* ``parse_rate``: share of answers the parser could read.
* ``accuracy_on_parsed``: accuracy among parseable answers only.
* ``premature_action_rate``: among traces whose gold is not ACT, the share where
  the model chose ACT.
* ``missed_action_rate``: among traces whose gold is ACT, the share where the
  model chose a different valid primitive (unparseable answers are reported in
  ``parse_rate``, not here).
* ``brier`` / ``ece`` / ``nll``: only when per-primitive probabilities exist
  (the decision-readout arm).

Intervals are percentile bootstraps over traces with a fixed seed, so two runs on
the same predictions report the same interval.
"""

from __future__ import annotations

import math
import random
from collections import Counter, defaultdict
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field

from steerbench_tinker.reward import PRESETS, outcome
from steerbench_tinker.schema import ACTIONS

INVALID = "INVALID"


@dataclass(frozen=True)
class Scored:
    id: str
    domain: str
    gold: str
    pred: str | None  # None = unparseable
    status: str = "ok"
    probs: Mapping[str, float] | None = field(default=None)

    @property
    def correct(self) -> bool:
        return self.pred == self.gold


def _rate(num: int, den: int) -> float | None:
    return num / den if den else None


def _bootstrap_ci(
    values: Sequence[float], n_boot: int = 2000, seed: int = 0, alpha: float = 0.05
) -> tuple[float, float] | None:
    if not values:
        return None
    rng = random.Random(seed)
    n = len(values)
    means = sorted(sum(values[rng.randrange(n)] for _ in range(n)) / n for _ in range(n_boot))
    lo = means[math.floor(alpha / 2 * n_boot)]
    hi = means[min(n_boot - 1, math.ceil((1 - alpha / 2) * n_boot) - 1)]
    return (lo, hi)


def _calibration(items: Sequence[Scored], n_bins: int = 10) -> dict[str, float]:
    brier = nll = 0.0
    bins: list[list[tuple[float, bool]]] = [[] for _ in range(n_bins)]
    for s in items:
        assert s.probs is not None
        p = {a: float(s.probs.get(a, 0.0)) for a in ACTIONS}
        brier += sum((p[a] - (1.0 if a == s.gold else 0.0)) ** 2 for a in ACTIONS)
        nll += -math.log(max(p[s.gold], 1e-12))
        top = max(ACTIONS, key=lambda a: p[a])
        conf = p[top]
        bins[min(n_bins - 1, int(conf * n_bins))].append((conf, top == s.gold))
    n = len(items)
    ece = sum(
        len(b) / n * abs(sum(c for c, _ in b) / len(b) - sum(ok for _, ok in b) / len(b))
        for b in bins
        if b
    )
    return {"brier": brier / n, "nll": nll / n, "ece": ece}


def compute(items: Sequence[Scored], *, n_boot: int = 2000, seed: int = 0) -> dict:
    n = len(items)
    if n == 0:
        raise ValueError("no scored items")
    correct = [1.0 if s.correct else 0.0 for s in items]
    parsed = [s for s in items if s.pred is not None]
    non_act = [s for s in items if s.gold != "ACT"]
    act = [s for s in items if s.gold == "ACT"]

    confusion: dict[str, dict[str, int]] = {g: {p: 0 for p in (*ACTIONS, INVALID)} for g in ACTIONS}
    for s in items:
        confusion[s.gold][s.pred or INVALID] += 1

    per_action = {}
    for a in ACTIONS:
        gold_a = [s for s in items if s.gold == a]
        pred_a = [s for s in items if s.pred == a]
        per_action[a] = {
            "support": len(gold_a),
            "predicted": len(pred_a),
            "recall": _rate(sum(s.correct for s in gold_a), len(gold_a)),
            "precision": _rate(sum(s.correct for s in pred_a), len(pred_a)),
        }

    by_domain: dict[str, list[Scored]] = defaultdict(list)
    for s in items:
        by_domain[s.domain].append(s)
    per_domain = {
        d: {"n": len(v), "accuracy": sum(s.correct for s in v) / len(v)}
        for d, v in sorted(by_domain.items())
    }

    outcomes = Counter(outcome(s.gold, s.pred) for s in items)
    rewards = {
        name: sum(getattr(cfg, outcome(s.gold, s.pred)) for s in items) / n
        for name, cfg in PRESETS.items()
    }

    result = {
        "n": n,
        "accuracy": sum(correct) / n,
        "accuracy_ci95": _bootstrap_ci(correct, n_boot, seed),
        "parse_rate": len(parsed) / n,
        "accuracy_on_parsed": _rate(sum(s.correct for s in parsed), len(parsed)),
        "premature_action_rate": _rate(sum(s.pred == "ACT" for s in non_act), len(non_act)),
        "missed_action_rate": _rate(
            sum(s.pred is not None and s.pred != "ACT" for s in act), len(act)
        ),
        "outcomes": dict(outcomes),
        "mean_reward": rewards,
        "prediction_counts": dict(Counter(s.pred or INVALID for s in items)),
        "parse_status_counts": dict(Counter(s.status for s in items)),
        "per_action": per_action,
        "per_domain": per_domain,
        "confusion": confusion,
    }
    with_probs = [s for s in items if s.probs is not None]
    if with_probs:
        result["calibration"] = _calibration(with_probs)
    return result


def paired_difference(
    a: Sequence[Scored], b: Sequence[Scored], *, n_boot: int = 5000, seed: int = 0
) -> dict:
    """Accuracy(b) - accuracy(a) on the traces both runs scored, with a paired bootstrap CI.

    Pairing by trace id removes between-trace variance, which is what makes a
    difference of a few points on a few hundred traces interpretable.
    """
    by_id_a = {s.id: s for s in a}
    pairs = [(by_id_a[s.id], s) for s in b if s.id in by_id_a]
    if not pairs:
        raise ValueError("the two runs share no trace ids")
    diffs = [float(y.correct) - float(x.correct) for x, y in pairs]
    ci = _bootstrap_ci(diffs, n_boot, seed)
    return {
        "n_paired": len(pairs),
        "accuracy_a": sum(x.correct for x, _ in pairs) / len(pairs),
        "accuracy_b": sum(y.correct for _, y in pairs) / len(pairs),
        "difference": sum(diffs) / len(diffs),
        "difference_ci95": ci,
        "b_fixes": sum(1 for x, y in pairs if not x.correct and y.correct),
        "b_breaks": sum(1 for x, y in pairs if x.correct and not y.correct),
        "significant_at_95": bool(ci and (ci[0] > 0 or ci[1] < 0)),
    }
