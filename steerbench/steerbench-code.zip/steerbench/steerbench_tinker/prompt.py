"""Prompt construction shared by every arm (zero-shot, SFT, RL, decision readout).

Keeping one prompt builder means the arms differ only in how the decision is
read out and trained, not in what the model is shown.
"""

from __future__ import annotations

import json

from steerbench_tinker.schema import ACTION_DESCRIPTIONS, ACTIONS, Trace

SYSTEM_PROMPT = (
    "You are the control policy for a collaborative agent. At each step you choose exactly "
    "one intervention:\n"
    + "\n".join(f"- {a}: {ACTION_DESCRIPTIONS[a]}" for a in ACTIONS)
    + "\nChoose ACT only when the task has everything it needs and acting is permitted."
)

JSON_INSTRUCTION = (
    'Respond with only a JSON object of the form {"action": "<one of '
    + "|".join(ACTIONS)
    + '>", "rationale": "<one sentence>"} and nothing else.'
)


def situation_text(trace: Trace) -> str:
    """The task, memory and observation, without any answer-format instruction."""
    memory = "\n".join(f"- {m}" for m in trace.memory) if trace.memory else "(empty)"
    return (
        f"Domain: {trace.domain}\n\n"
        f"Task:\n{trace.task}\n\n"
        f"Memory:\n{memory}\n\n"
        f"Observation:\n{trace.observation}"
    )


def user_message(trace: Trace) -> str:
    """The user turn for the generative (JSON) arms."""
    return f"{situation_text(trace)}\n\n{JSON_INSTRUCTION}"


def target_completion(trace: Trace, include_rationale: bool = True) -> str:
    """The assistant turn used as the SFT target."""
    obj: dict[str, str] = {"action": trace.gold_action}
    if include_rationale and trace.rationale:
        obj["rationale"] = trace.rationale
    return json.dumps(obj, ensure_ascii=False)


def sft_conversation(trace: Trace, include_rationale: bool = True) -> dict:
    return {
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_message(trace)},
            {"role": "assistant", "content": target_completion(trace, include_rationale)},
        ]
    }
