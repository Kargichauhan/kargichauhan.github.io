"""Offline analysis: no Tinker calls, no API key.

Re-score raw outputs from any model (e.g. the earlier TinyLlama run) with the
strict and lenient parsers:

    python -m steerbench_tinker.analyze rescore --raw tinyllama_outputs.jsonl \\
        --traces data/test.jsonl --out results/tinyllama_rescored

Paired comparison of two runs on the same traces:

    python -m steerbench_tinker.analyze compare results/sft results/rl_asym --view strict

Collect every run under ``results/`` into one summary table:

    python -m steerbench_tinker.analyze summary results/ --out results/summary.json
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from steerbench_tinker.metrics import compute, paired_difference
from steerbench_tinker.predictions import generative_row, read_rows, to_scored, write_rows
from steerbench_tinker.run_meta import write_meta
from steerbench_tinker.schema import load_traces

RAW_KEYS = ("raw", "output", "response", "completion", "generation", "text")


def rescore(raw_path: str, traces_path: str, out: str) -> dict:
    traces = {t.id: t for t in load_traces(traces_path)}
    rows, unmatched = [], 0
    for r in read_rows(raw_path):
        tid = str(r.get("id") or r.get("trace_id") or "")
        if tid not in traces:
            unmatched += 1
            continue
        raw = next((r[k] for k in RAW_KEYS if isinstance(r.get(k), str)), None)
        if raw is None:
            raise SystemExit(f"row {tid} has none of the raw-output keys {RAW_KEYS}")
        rows.append(generative_row(traces[tid], raw))
    if not rows:
        raise SystemExit("no raw outputs matched a trace id")
    write_rows(rows, Path(out) / "predictions.jsonl")
    metrics = {
        "arm": "generative_rescored",
        "strict": compute(to_scored(rows, "strict")),
        "lenient": compute(to_scored(rows, "lenient")),
        "unmatched_rows": unmatched,
    }
    (Path(out) / "metrics.json").write_text(json.dumps(metrics, indent=2) + "\n")
    write_meta(out, arm="generative_rescored", raw_path=raw_path, traces_path=traces_path)
    s, l_ = metrics["strict"], metrics["lenient"]
    print(
        f"strict acc {s['accuracy']:.3f} (parse {s['parse_rate']:.2f}) -> "
        f"lenient acc {l_['accuracy']:.3f} (parse {l_['parse_rate']:.2f}); "
        f"{unmatched} unmatched rows"
    )
    return metrics


def _view_for(rows: list[dict], view: str) -> str:
    if view in rows[0]:
        return view
    return "readout" if "readout" in rows[0] else "strict"


def compare(run_a: str, run_b: str, view: str) -> dict:
    rows_a = read_rows(Path(run_a) / "predictions.jsonl")
    rows_b = read_rows(Path(run_b) / "predictions.jsonl")
    result = paired_difference(
        to_scored(rows_a, _view_for(rows_a, view)), to_scored(rows_b, _view_for(rows_b, view))
    )
    lo, hi = result["difference_ci95"]
    print(
        f"{run_b} - {run_a}: {result['difference']:+.3f} accuracy "
        f"[95% CI {lo:+.3f}, {hi:+.3f}] over {result['n_paired']} paired traces; "
        f"fixes {result['b_fixes']}, breaks {result['b_breaks']}"
    )
    return result


def summary(results_dir: str, out: str | None) -> list[dict]:
    table = []
    for metrics_path in sorted(Path(results_dir).rglob("metrics.json")):
        m = json.loads(metrics_path.read_text())
        meta_path = metrics_path.with_name("meta.json")
        meta = json.loads(meta_path.read_text()) if meta_path.exists() else {}
        for view in ("strict", "lenient", "readout"):
            if view not in m:
                continue
            v = m[view]
            table.append(
                {
                    "run": str(metrics_path.parent.relative_to(results_dir)),
                    "view": view,
                    "model": meta.get("model_name"),
                    "checkpoint": meta.get("checkpoint"),
                    "n": v["n"],
                    "accuracy": v["accuracy"],
                    "accuracy_ci95": v["accuracy_ci95"],
                    "parse_rate": v["parse_rate"],
                    "premature_action_rate": v["premature_action_rate"],
                    "missed_action_rate": v["missed_action_rate"],
                    "per_action_recall": {a: x["recall"] for a, x in v["per_action"].items()},
                    "calibration": v.get("calibration"),
                }
            )
    if out:
        Path(out).write_text(json.dumps(table, indent=2) + "\n")
    for row in table:
        print(
            f"{row['run']:<32} {row['view']:<8} acc {row['accuracy']:.3f} "
            f"parse {row['parse_rate']:.2f} premature {row['premature_action_rate']}"
        )
    return table


def main(argv: list[str] | None = None) -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawTextHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("rescore")
    r.add_argument("--raw", required=True)
    r.add_argument("--traces", required=True)
    r.add_argument("--out", required=True)
    c = sub.add_parser("compare")
    c.add_argument("run_a")
    c.add_argument("run_b")
    c.add_argument("--view", default="strict", choices=("strict", "lenient", "readout"))
    s = sub.add_parser("summary")
    s.add_argument("results_dir")
    s.add_argument("--out")
    args = p.parse_args(argv)
    if args.cmd == "rescore":
        rescore(args.raw, args.traces, args.out)
    elif args.cmd == "compare":
        compare(args.run_a, args.run_b, args.view)
    else:
        summary(args.results_dir, args.out)


if __name__ == "__main__":
    main()
