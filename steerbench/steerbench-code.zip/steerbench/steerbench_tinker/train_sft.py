"""Supervised fine-tuning on the SteerBench training traces (LoRA on Tinker).

    python -m steerbench_tinker.train_sft log_path=runs/sft_llama1b

The run writes ``checkpoints.jsonl`` into ``log_path``; ``train_rl`` starts from
its last state and ``eval_generative`` scores its sampler weights.
"""

from __future__ import annotations

import asyncio
import sys

import chz
from tinker_cookbook import cli_utils, hyperparam_utils, model_info
from tinker_cookbook.renderers import TrainOnWhat
from tinker_cookbook.supervised import train
from tinker_cookbook.supervised.data import FromConversationFileBuilder
from tinker_cookbook.supervised.types import ChatDatasetBuilderCommonConfig

from steerbench_tinker.eval_generative import DEFAULT_MODEL


def build_config_blueprint(
    model_name: str = DEFAULT_MODEL,
    train_file: str = "data/sft_train.jsonl",
) -> chz.Blueprint[train.Config]:
    renderer_name = model_info.get_recommended_renderer_name(model_name)
    dataset = FromConversationFileBuilder(
        common_config=ChatDatasetBuilderCommonConfig(
            model_name_for_tokenizer=model_name,
            renderer_name=renderer_name,
            max_length=2048,
            batch_size=32,
            train_on_what=TrainOnWhat.LAST_ASSISTANT_MESSAGE,
        ),
        file_path=train_file,
        test_size=0,  # held-out scoring is done by eval_generative on data/test.jsonl
    )
    return chz.Blueprint(train.Config).apply(
        {
            "log_path": cli_utils.runs_path("steerbench_sft"),
            "model_name": model_name,
            "recipe_name": "steerbench_sft",
            "renderer_name": renderer_name,
            "dataset_builder": dataset,
            "learning_rate": hyperparam_utils.get_lr(model_name),
            "lr_schedule": "linear",
            "num_epochs": 3,
            "lora_rank": 16,  # matches the earlier TinyLlama LoRA (r=16)
            "save_every": 50,
            "eval_every": 0,
        }
    )


def main(config: train.Config) -> None:
    cli_utils.check_log_dir(config.log_path, behavior_if_exists="ask")
    asyncio.run(train.main(config))


if __name__ == "__main__":
    model_name = cli_utils.model_name_from_argv(sys.argv[1:], default=DEFAULT_MODEL)
    blueprint = build_config_blueprint(model_name)
    blueprint.make_from_argv(sys.argv[1:])
    main(blueprint.make())
