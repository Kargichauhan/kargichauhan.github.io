"""SteerBench as a Tinker Cookbook RL environment.

``SteerBenchEnv`` subclasses the cookbook's single-turn ``ProblemEnv`` and keeps
its prompt construction, stop handling and logging, but replaces the reward with
the decomposed one in ``steerbench_tinker.reward`` and reports every component as
a training metric (premature actions, missed actions, invalid outputs), so a run's
logs show *how* the policy is changing, not just whether reward went up.
"""

import math
import random
from collections.abc import Sequence
from functools import partial

import chz
import tinker
from tinker_cookbook import renderers
from tinker_cookbook.rl.problem_env import ProblemEnv, ProblemGroupBuilder
from tinker_cookbook.rl.types import (
    Action,
    ActionExtra,
    EnvGroupBuilder,
    RLDataset,
    RLDatasetBuilder,
    StepResult,
)
from tinker_cookbook.tokenizer_utils import get_tokenizer
from tinker_cookbook.utils import logtree

from steerbench_tinker.parse import ParseResult, ParseStatus, parse_strict
from steerbench_tinker.prompt import SYSTEM_PROMPT, user_message
from steerbench_tinker.reward import PRESETS, RewardConfig, score
from steerbench_tinker.schema import ACTIONS, Trace, read_normalized

OUTCOMES = ("correct", "premature_act", "missed_act", "other_wrong", "invalid")


class SteerBenchEnv(ProblemEnv):
    def __init__(
        self,
        trace: Trace,
        renderer: renderers.Renderer,
        reward_config: RewardConfig,
        convo_prefix: list[renderers.Message] | None = None,
    ):
        super().__init__(
            renderer,
            convo_prefix=convo_prefix
            if convo_prefix is not None
            else [{"role": "system", "content": SYSTEM_PROMPT}],
            format_coef=0.0,  # format is priced inside reward_config.invalid
        )
        self.trace = trace
        self.reward_config = reward_config

    # ProblemEnv's abstract interface (used by the cookbook's generic evaluators).
    def get_question(self) -> str:
        return user_message(self.trace)

    def check_format(self, sample_str: str) -> bool:
        return parse_strict(sample_str).ok

    def check_answer(self, sample_str: str) -> bool:
        return parse_strict(sample_str).action == self.trace.gold_action

    def get_reference_answer(self) -> str:
        return self.trace.gold_action

    async def step(self, action: Action, *, extra: ActionExtra | None = None) -> StepResult:
        message, termination = self.renderer.parse_response(action)
        content = renderers.get_text_content(message)
        parsed = parse_strict(content)
        # A complete JSON answer is accepted however the turn ended (stop sequence or EOS);
        # an unparseable answer from a malformed / cut-off turn is labelled truncated.
        if not termination.is_clean and not parsed.ok:
            parsed = ParseResult(ParseStatus.TRUNCATED)
        reward, kind = score(self.trace.gold_action, parsed, self.reward_config)

        with logtree.scope_header("SteerBench decision"):
            logtree.table_from_dict(
                {
                    "trace_id": self.trace.id,
                    "domain": self.trace.domain,
                    "gold": self.trace.gold_action,
                    "predicted": parsed.action or "-",
                    "parse_status": parsed.status.value,
                    "outcome": kind,
                    "reward": f"{reward:.3f}",
                },
                caption="Reward components",
            )
            logtree.log_text(content[:2000])

        metrics: dict[str, float] = {f"outcome/{o}": float(o == kind) for o in OUTCOMES}
        metrics["format"] = float(parsed.ok)
        metrics["correct"] = float(kind == "correct")
        for a in ACTIONS:
            metrics[f"pred/{a}"] = float(parsed.action == a)
        return StepResult(
            reward=reward,
            episode_done=True,
            next_observation=tinker.ModelInput.empty(),
            next_stop_condition=self.stop_condition,
            metrics=metrics,
        )


class SteerBenchRLDataset(RLDataset):
    def __init__(
        self,
        traces: Sequence[Trace],
        *,
        batch_size: int,
        group_size: int,
        renderer: renderers.Renderer,
        reward_config: RewardConfig,
        shuffle_seed: int | None = 0,
    ):
        self.traces = list(traces)
        if shuffle_seed is not None:
            random.Random(shuffle_seed).shuffle(self.traces)
        self.batch_size = batch_size
        self.group_size = group_size
        self.renderer = renderer
        self.reward_config = reward_config

    def get_batch(self, index: int) -> Sequence[EnvGroupBuilder]:
        start = index * self.batch_size
        batch = self.traces[start : start + self.batch_size]
        return [
            ProblemGroupBuilder(
                env_thunk=partial(SteerBenchEnv, t, self.renderer, self.reward_config),
                num_envs=self.group_size,
                dataset_name=f"steerbench/{t.domain}",
            )
            for t in batch
        ]

    def __len__(self) -> int:
        return math.ceil(len(self.traces) / self.batch_size)


@chz.chz
class SteerBenchDatasetBuilder(RLDatasetBuilder):
    train_path: str
    model_name_for_tokenizer: str
    renderer_name: str
    test_path: str | None = None
    batch_size: int = 64
    group_size: int = 8
    reward_preset: str = "asymmetric"
    seed: int = 0

    async def __call__(self) -> tuple[SteerBenchRLDataset, SteerBenchRLDataset | None]:
        if self.reward_preset not in PRESETS:
            raise ValueError(f"reward_preset must be one of {sorted(PRESETS)}")
        reward_config = PRESETS[self.reward_preset]
        renderer = renderers.get_renderer(
            self.renderer_name, tokenizer=get_tokenizer(self.model_name_for_tokenizer)
        )
        train = SteerBenchRLDataset(
            read_normalized(self.train_path),
            batch_size=self.batch_size,
            group_size=self.group_size,
            renderer=renderer,
            reward_config=reward_config,
            shuffle_seed=self.seed,
        )
        test = None
        if self.test_path:
            test_traces = read_normalized(self.test_path)
            test = SteerBenchRLDataset(
                test_traces,
                batch_size=len(test_traces),
                group_size=1,
                renderer=renderer,
                reward_config=reward_config,
                shuffle_seed=None,
            )
        return train, test
