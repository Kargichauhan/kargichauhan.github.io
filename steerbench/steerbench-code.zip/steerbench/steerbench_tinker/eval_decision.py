"""Evaluate the decision readout (probability over the five primitives) on the test traces.

    python -m steerbench_tinker.eval_decision out=results/decision_zeroshot_llama1b

Zero-shot, this measures what the model already prefers once the output format is
taken out of the picture. With ``checkpoint=`` it scores a trained decision model.
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
from pathlib import Path

import chz
import tinker
from tinker_cookbook import model_info, renderers
from tinker_cookbook.recipes.decisions import DecisionRenderer, sample_decision
from tinker_cookbook.tokenizer_utils import get_tokenizer

from steerbench_tinker.decision_arm import trace_decision
from steerbench_tinker.eval_generative import DEFAULT_MODEL
from steerbench_tinker.metrics import compute
from steerbench_tinker.predictions import decision_row, to_scored, write_rows
from steerbench_tinker.run_meta import file_sha256, write_meta
from steerbench_tinker.schema import Trace, read_normalized

logger = logging.getLogger(__name__)


@chz.chz
class Config:
    out: str
    model_name: str = DEFAULT_MODEL
    checkpoint: str | None = None
    renderer_name: str | None = None
    test_path: str = "data/test.jsonl"
    concurrency: int = 32
    limit: int | None = None
    base_url: str | None = None


async def score_traces(
    traces: list[Trace],
    client: tinker.SamplingClient,
    decision_renderer: DecisionRenderer,
    concurrency: int = 32,
) -> list[dict]:
    sem = asyncio.Semaphore(concurrency)

    async def one(trace: Trace) -> dict:
        async with sem:
            probs = await sample_decision(client, decision_renderer.render(trace_decision(trace)))
        return decision_row(trace, probs)

    return list(await asyncio.gather(*(one(t) for t in traces)))


async def run(cfg: Config) -> dict:
    traces = read_normalized(cfg.test_path)
    if cfg.limit is not None:
        traces = traces[: cfg.limit]
    renderer_name = cfg.renderer_name or model_info.get_recommended_renderer_name(cfg.model_name)
    renderer = renderers.get_renderer(renderer_name, get_tokenizer(cfg.model_name))
    decision_renderer = DecisionRenderer(renderer)
    service = tinker.ServiceClient(base_url=cfg.base_url)
    if cfg.checkpoint:
        client = service.create_sampling_client(
            model_path=cfg.checkpoint, base_model=cfg.model_name
        )
    else:
        client = service.create_sampling_client(base_model=cfg.model_name)

    start = time.time()
    rows = await score_traces(traces, client, decision_renderer, cfg.concurrency)
    elapsed = time.time() - start

    out = Path(cfg.out)
    write_rows(rows, out / "predictions.jsonl")
    metrics = {
        "arm": "decision",
        "readout": compute(to_scored(rows, "readout")),
        "seconds": round(elapsed, 1),
    }
    (out / "metrics.json").write_text(json.dumps(metrics, indent=2) + "\n")
    write_meta(
        out,
        arm="decision",
        model_name=cfg.model_name,
        checkpoint=cfg.checkpoint,
        renderer_name=renderer_name,
        test_path=cfg.test_path,
        test_sha256=file_sha256(cfg.test_path),
        n=len(traces),
    )
    m = metrics["readout"]
    print(
        f"{cfg.out}: decision acc {m['accuracy']:.3f} | premature "
        f"{m['premature_action_rate']} | brier {m['calibration']['brier']:.3f} | {elapsed:.0f}s"
    )
    return metrics


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    asyncio.run(run(chz.entrypoint(Config)))
