"""GRPO-style RL on SteerBench with the decomposed reward (LoRA on Tinker).

    # from the SFT checkpoint, asymmetric reward (the main arm)
    python -m steerbench_tinker.train_rl log_path=runs/rl_asym sft_log_path=runs/sft_llama1b
    # ablation: same start, symmetric reward
    python -m steerbench_tinker.train_rl log_path=runs/rl_sym sft_log_path=runs/sft_llama1b \\
        dataset_builder.reward_preset=symmetric

Each trace is sampled ``group_size`` times; advantages are computed within the
group, so a trace where every sample earns the same reward teaches nothing.
``remove_constant_reward_groups`` drops those groups and the logged
``outcome/*`` metrics show how often that happens.
"""

from __future__ import annotations

import asyncio
import sys

import chz
from tinker_cookbook import checkpoint_utils, cli_utils, hyperparam_utils, model_info
from tinker_cookbook.rl import train

from steerbench_tinker.env import SteerBenchDatasetBuilder
from steerbench_tinker.eval_generative import DEFAULT_MODEL


def _sft_state_path(sft_log_path: str) -> str:
    record = checkpoint_utils.get_last_checkpoint(sft_log_path, required_key="state_path")
    if record is None or record.state_path is None:
        raise SystemExit(f"no state checkpoint found in {sft_log_path}/checkpoints.jsonl")
    return record.state_path


def build_config_blueprint(model_name: str = DEFAULT_MODEL) -> chz.Blueprint[train.Config]:
    renderer_name = model_info.get_recommended_renderer_name(model_name)
    # The builder is given as a factory plus sub-parameters (not an instance) so any of
    # its fields can be overridden from the command line, e.g.
    # dataset_builder.reward_preset=symmetric or dataset_builder.group_size=16.
    return chz.Blueprint(train.Config).apply(
        {
            "model_name": model_name,
            "recipe_name": "steerbench_rl",
            "renderer_name": renderer_name,
            "log_path": cli_utils.runs_path("steerbench_rl"),
            "dataset_builder": SteerBenchDatasetBuilder,
            "dataset_builder.train_path": "data/train.jsonl",
            "dataset_builder.test_path": "data/test.jsonl",
            "dataset_builder.model_name_for_tokenizer": model_name,
            "dataset_builder.renderer_name": renderer_name,
            "dataset_builder.batch_size": 64,
            "dataset_builder.group_size": 8,
            "dataset_builder.reward_preset": "asymmetric",
            # RL steps are noisier than SFT steps; start well below the SFT rate.
            "learning_rate": hyperparam_utils.get_lr(model_name) / 4,
            "lora_rank": 16,
            "max_tokens": 128,
            "temperature": 1.0,
            "remove_constant_reward_groups": True,
            "eval_every": 5,
            "save_every": 10,
        }
    )


def main(config: train.Config) -> None:
    cli_utils.check_log_dir(config.log_path, behavior_if_exists="ask")
    asyncio.run(train.main(config))


if __name__ == "__main__":
    argv = sys.argv[1:]
    sft_log_path = None
    for arg in list(argv):
        if arg.startswith("sft_log_path="):
            sft_log_path = arg.split("=", 1)[1]
            argv.remove(arg)
    model_name = cli_utils.model_name_from_argv(argv, default=DEFAULT_MODEL)
    blueprint = build_config_blueprint(model_name)
    if sft_log_path:
        blueprint = blueprint.apply({"load_checkpoint_path": _sft_state_path(sft_log_path)})
    blueprint.make_from_argv(argv)
    main(blueprint.make())
