# SteerBench

**When should an agent act, and when should it ask, wait, remember or forget?**
SteerBench is a set of agent decision points, each labelled with the one correct
intervention primitive: `ACT`, `ASK`, `WAIT`, `REMEMBER` or `FORGET`. This repo is the
post-training harness for it, with two interchangeable backends:

- **Your own GPUs** (`run_local.sh`): Hugging Face + LoRA, with hand-written SFT, GRPO
  and decision-training loops.
- **[Tinker](https://thinkingmachines.ai/tinker/)** (`run_all.sh`): the same benchmark as
  an environment in the open-source
  [Tinker Cookbook](https://github.com/thinking-machines-lab/tinker-cookbook).

Both share one prompt, one pair of parsers, one reward and one metrics module, and
write results in the same format.

## Why this experiment

A first zero-shot run of TinyLlama-1.1B on 100 SteerBench traces scored 11% action
accuracy, but 67 of the 100 answers could not be parsed at all and none were valid JSON.
That number mixes two failures: the model **didn't follow the output format**, and
the model **made the wrong call**. They need different fixes, so this repo measures
them separately and then asks which post-training path fixes the judgment cheapest.

| Arm | What it answers |
|---|---|
| `0_zeroshot_generative` | How the base model does when it must write the JSON. Scored twice: **strict** (the JSON is the answer) and **lenient** (recover the choice from anywhere in the text). Lenient minus strict = errors that are only formatting. |
| `0_zeroshot_decision` | The same model with formatting removed: logprobs over the five primitives at one answer position ([cookbook `decisions` recipe](https://github.com/thinking-machines-lab/tinker-cookbook/tree/main/tinker_cookbook/recipes/decisions)). |
| `1_sft` | LoRA SFT on the training traces. |
| `2_rl_asymmetric` | GRPO from the SFT checkpoint. Acting prematurely is the most expensive mistake. |
| `2_rl_symmetric` | Same start, every mistake costs the same. **The ablation:** does pricing premature action change behaviour beyond accuracy? |
| `3_decision_trained` | Cross-entropy on the decision readout: one weighted token per trace, no rollouts. Also gives calibrated probabilities (Brier, ECE). |

Every comparison is paired by trace id with a bootstrap 95% interval
(`analyze compare`), so a difference of a few points on 500 traces can be told apart
from noise.

## Reward

```
                     symmetric   asymmetric
correct                 1.0         1.0
premature ACT           0.0        -1.0    # acted when it should have asked/waited/...
missed ACT              0.0        -0.25   # was too cautious when acting was right
other wrong             0.0         0.0
unparseable / cut off  -0.1        -0.5
```

For every preset an unparseable answer earns strictly less than every valid non-ACT
answer, so the policy can never raise its reward by emitting garbage when unsure.
`tests/test_core.py::test_garbage_is_never_a_good_bet` checks this for every gold
label. Each outcome is logged as its own training metric (`outcome/premature_act`, …),
so a run's curves show *which* mistakes are going away.

## Run it on your own GPUs

```bash
pip install -e ".[local,dev]"
pytest                                                          # 54 tests, CPU only

TRACES=path/to/steerbench_traces.jsonl SMOKE=1 ./run_local.sh   # every arm, tiny budget
TRACES=path/to/steerbench_traces.jsonl ./run_local.sh           # the real run
# on SLURM:
sbatch --export=ALL,TRACES=/path/to/traces.jsonl slurm_job.sh
```

The main model is `Qwen/Qwen2.5-1.5B-Instruct` (ungated; `MODEL=...` to change). The
first step also re-runs the TinyLlama-1.1B-Chat baseline on the full test set with the
new parsers. One 24GB+ GPU is enough for a 1.5B model. Rough wall-clock on one A100:
zero-shot evals take minutes, SFT well under an hour, each RL run a few hours (sampling
dominates), decision training under an hour; treat these as estimates, not measurements.

How the local RL works, in four lines (`steerbench_tinker/local/train_rl.py`):
sample 8 answers per trace, score each with the reward preset, subtract the group's mean
reward to get each answer's advantage, and take one gradient step on
`-sum(advantage * log p(answer)) / answer tokens`. Groups where every answer scored the
same carry no signal and are skipped; the log records how often that happens.

## Run it on Tinker

```bash
pip install -e ".[tinker,dev]"     # cookbook from GitHub main (has the decisions recipe)
export TINKER_API_KEY=...

TRACES=path/to/steerbench_traces.jsonl SMOKE=1 ./run_all.sh   # 20 traces, every arm
TRACES=path/to/steerbench_traces.jsonl ./run_all.sh           # full experiment
```

`prepare_data` accepts JSONL or JSON and maps common field names automatically
(`trace_id`, `label.action`, `scoped_memory`, …). For anything else:
`--map gold_action=meta.expected`. An existing `split` field (your 2,000 / 500 split)
is kept; otherwise the split is a stratified hash of trace ids, independent of file
order. `data/data_card.json` records counts and file hashes.

On Tinker the default model is `meta-llama/Llama-3.2-1B`; pass `MODEL=...` to run
another (check Tinker's current model list). Rank-16 LoRA throughout, matching the
earlier TinyLlama run.

Re-score outputs from any other model without spending anything:

```bash
python -m steerbench_tinker.analyze rescore --raw old_outputs.jsonl \
    --traces data/test.jsonl --out results/tinyllama_rescored
```

## Outputs

Every result directory holds `predictions.jsonl` (raw text and both parses for every
trace), `metrics.json` and `meta.json` (model, checkpoint path, renderer, prompt hash,
test-file hash, git revision). Any number can be traced to the run that produced it
and re-scored without re-sampling.

Metric definitions are at the top of `steerbench_tinker/metrics.py`.

## Tests

```bash
pytest          # 54 tests, CPU only, no API key: parser, reward properties, metrics,
                # split, the Tinker env through the real cookbook interfaces, and every
                # local arm run end to end on a tiny random model
```

## Layout

```
steerbench_tinker/
  schema.py        trace format + tolerant loader
  prompt.py        one prompt shared by every arm
  parse.py         strict and lenient parsers
  reward.py        reward presets
  env.py           SteerBenchEnv (ProblemEnv) + RLDataset + chz builder
  decision_arm.py  traces as cookbook Decisions
  metrics.py       accuracy, premature/missed action, calibration, paired bootstrap
  prepare_data.py  validate, split, write SFT conversations + data card
  eval_generative.py / eval_decision.py / train_sft.py / train_rl.py / train_decision.py
  analyze.py       rescore, compare, summary (offline)
  local/           Hugging Face backend: evaluate, train_sft, train_rl, train_decision
```
