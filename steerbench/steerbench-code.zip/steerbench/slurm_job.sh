#!/usr/bin/env bash
# SLURM wrapper for run_local.sh. Edit the partition/account lines for your cluster.
#
#   sbatch --export=ALL,TRACES=/path/to/traces.jsonl,SMOKE=1 slurm_job.sh   # smoke first
#   sbatch --export=ALL,TRACES=/path/to/traces.jsonl slurm_job.sh
#
#SBATCH --job-name=steerbench
#SBATCH --gres=gpu:1
#SBATCH --cpus-per-task=8
#SBATCH --mem=48G
#SBATCH --time=12:00:00
#SBATCH --output=logs/steerbench_%j.out
##SBATCH --partition=YOUR_GPU_PARTITION
##SBATCH --account=YOUR_ACCOUNT

set -euo pipefail
mkdir -p logs
cd "${SLURM_SUBMIT_DIR:-.}"
# Activate your environment here, for example:
# source ~/miniconda3/etc/profile.d/conda.sh && conda activate steerbench
nvidia-smi
./run_local.sh
