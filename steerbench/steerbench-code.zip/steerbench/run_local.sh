#!/usr/bin/env bash
# Full SteerBench experiment on your own GPU(s): no Tinker account needed.
#
#   TRACES=path/to/steerbench_traces.jsonl SMOKE=1 ./run_local.sh   # ~10 min check, every arm
#   TRACES=path/to/steerbench_traces.jsonl ./run_local.sh           # the real run
#
# Every step writes predictions + metrics + meta.json, so any step can be re-run alone,
# and `python -m steerbench_tinker.analyze` reads the results exactly as it reads Tinker ones.
set -euo pipefail

: "${TRACES:?set TRACES=path/to/your/traces.jsonl}"
MODEL="${MODEL:-Qwen/Qwen2.5-1.5B-Instruct}"
BASELINE_MODEL="${BASELINE_MODEL:-TinyLlama/TinyLlama-1.1B-Chat-v1.0}"
TAG="${TAG:-qwen1.5b}"
EVAL_LIMIT=(); STEPS_RL=200; STEPS_CAP=()
if [[ "${SMOKE:-0}" == "1" ]]; then
  EVAL_LIMIT=(--limit 20); STEPS_RL=3; STEPS_CAP=(--max-steps 3); TAG="${TAG}_smoke"
fi
R="results/${TAG}"; RUNS="runs/${TAG}"
EV="python -m steerbench_tinker.local.evaluate"

python -m steerbench_tinker.prepare_data --traces "$TRACES" --out data

# 0. Zero-shot. The TinyLlama run re-measures the old baseline on the full test set with
#    the new parsers; the main model is read out both ways.
$EV --readout generative --model "$BASELINE_MODEL" --out "$R/0_baseline_tinyllama" "${EVAL_LIMIT[@]}"
$EV --readout generative --model "$MODEL" --out "$R/0_zeroshot_generative" "${EVAL_LIMIT[@]}"
$EV --readout decision   --model "$MODEL" --out "$R/0_zeroshot_decision"   "${EVAL_LIMIT[@]}"

# 1. Supervised fine-tuning.
python -m steerbench_tinker.local.train_sft --model "$MODEL" --out "$RUNS/sft" "${STEPS_CAP[@]}"
$EV --readout generative --model "$MODEL" --adapter "$RUNS/sft/final" --out "$R/1_sft" "${EVAL_LIMIT[@]}"

# 2. RL from the SFT adapter: asymmetric reward (main) and symmetric (ablation).
for PRESET in asymmetric symmetric; do
  python -m steerbench_tinker.local.train_rl --model "$MODEL" --sft-adapter "$RUNS/sft/final" \
    --reward "$PRESET" --max-steps "$STEPS_RL" --out "$RUNS/rl_${PRESET}"
  $EV --readout generative --model "$MODEL" --adapter "$RUNS/rl_${PRESET}/final" \
    --out "$R/2_rl_${PRESET}" "${EVAL_LIMIT[@]}"
done

# 3. Decision readout trained with cross-entropy (scores the test set itself).
python -m steerbench_tinker.local.train_decision --model "$MODEL" --out "$RUNS/decision" "${STEPS_CAP[@]}"
mkdir -p "$R/3_decision_trained"
cp "$RUNS/decision/final_eval/"* "$R/3_decision_trained/"

# 4. Tables and paired comparisons.
python -m steerbench_tinker.analyze summary "$R" --out "$R/summary.json"
python -m steerbench_tinker.analyze compare "$R/0_zeroshot_generative" "$R/1_sft"
python -m steerbench_tinker.analyze compare "$R/1_sft" "$R/2_rl_asymmetric"
python -m steerbench_tinker.analyze compare "$R/2_rl_symmetric" "$R/2_rl_asymmetric"
python -m steerbench_tinker.analyze compare "$R/1_sft" "$R/3_decision_trained"
echo "done: send $R/summary.json to update the page"
